package com.flashdrop

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/** 点击设备后出现：发送框（文件/文本 + 表情） + 与该设备的全部记录。 */
@Composable
fun DeviceScreen(
    contact: Contact, online: Peer?, records: List<HistoryItem>, st: UiState, busy: Boolean, fileLocked: Boolean,
    onClose: () -> Unit, onSendText: (String) -> Unit, onPickFiles: () -> Unit,
    onAlias: (String) -> Unit, onDelete: (Long) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var mode by remember { mutableStateOf(0) }
    var tfv by remember { mutableStateOf(TextFieldValue("")) }
    var emoji by remember { mutableStateOf(false) }
    var aliasDlg by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<HistoryItem?>(null) }
    val name = contact.alias.ifBlank { contact.name }
    val isOnline = online != null
    val bytes = tfv.text.toByteArray().size
    val canSend = isOnline && !busy
    LaunchedEffect(st) { if (st is UiState.TextSent) { tfv = TextFieldValue(""); emoji = false } }
    LaunchedEffect(fileLocked) { if (fileLocked) mode = 0 }

    Surface(Modifier.fillMaxSize(), color = cs.background) {
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(horizontal = 20.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClose) { Text("‹ 返回") }
                Spacer(Modifier.weight(1f))
                TextButton({ aliasDlg = true }) { Text("备注") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(contact.avatar, contact.color, 52.dp, gray = !isOnline)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (isOnline) cs.onSurface else cs.onSurfaceVariant.copy(alpha = 0.6f))
                    Text("指纹 #${fp(contact.id)} · ${if (isOnline) "在线" else "离线"}" +
                        (if (contact.alias.isNotBlank()) " · 原名 ${contact.name}" else ""),
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(12.dp))

            Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium, color = cs.surfaceVariant, border = BorderStroke(1.dp, cs.outline)) {
                Column(Modifier.padding(14.dp)) {
                    Segment(listOf("发送文件", "发送文本"), mode, listOf(true, !fileLocked)) { mode = it }
                    Spacer(Modifier.height(10.dp))
                    if (mode == 0) {
                        Button(onPickFiles, Modifier.fillMaxWidth(), enabled = canSend, shape = RoundedCornerShape(14.dp)) { Text("选择文件并发送") }
                    } else {
                        OutlinedTextField(tfv, { tfv = it }, Modifier.fillMaxWidth(), minLines = 2, maxLines = 4,
                            shape = RoundedCornerShape(14.dp), placeholder = { Text("输入文字，可插入表情，仅通过蓝牙发送") })
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton({ emoji = !emoji }) { Text(if (emoji) "⌨ 键盘" else "😊 表情") }
                            Spacer(Modifier.weight(1f))
                            Text("%.1f / 100 KB".format(bytes / 1024.0), style = MaterialTheme.typography.labelMedium,
                                color = if (bytes > 100 * 1024) cs.error else cs.onSurfaceVariant)
                            Spacer(Modifier.width(8.dp))
                            Button({ onSendText(tfv.text) }, enabled = canSend && tfv.text.isNotBlank() && bytes <= 100 * 1024,
                                shape = RoundedCornerShape(14.dp)) { Text("发送") }
                        }
                        if (emoji) EmojiPanel { e ->
                            val s = tfv.selection
                            tfv = TextFieldValue(tfv.text.replaceRange(s.min, s.max, e), TextRange(s.min + e.length))
                        }
                    }
                    if (!isOnline) Text("设备离线，暂时无法发送；上线后会自动恢复", Modifier.padding(top = 6.dp),
                        style = MaterialTheme.typography.bodySmall, color = cs.error)
                    else if (busy) Text("正在传输中，请稍候", Modifier.padding(top = 6.dp),
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    if (fileLocked) Text("文件传输中，暂不可发送文字", Modifier.padding(top = 6.dp),
                        style = MaterialTheme.typography.bodySmall, color = cs.error)
                }
            }

            Spacer(Modifier.height(14.dp))
            Text("与 $name 的记录 · ${records.size}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            if (records.isEmpty()) Text("还没有与 TA 的传输记录", Modifier.fillMaxWidth().padding(top = 24.dp),
                textAlign = TextAlign.Center, color = cs.onSurfaceVariant)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(records, key = { it.id }) { h -> RecordRow(h, name, false, {}) { detail = h } }
            }
        }
    }

    detail?.let { h -> RecordDetail(h, name, { detail = null }) { onDelete(h.id); detail = null } }
    if (aliasDlg) {
        var v by remember { mutableStateOf(contact.alias) }
        AlertDialog(
            onDismissRequest = { aliasDlg = false }, shape = RoundedCornerShape(28.dp),
            title = { Text("给 ${contact.name} 设置备注", fontWeight = FontWeight.Bold) },
            text = { OutlinedTextField(v, { if (it.length <= 16) v = it }, singleLine = true, placeholder = { Text("备注名（留空则恢复原名）") }) },
            confirmButton = { Button({ onAlias(v); aliasDlg = false }, shape = RoundedCornerShape(14.dp)) { Text("保存") } },
            dismissButton = { TextButton({ aliasDlg = false }) { Text("取消") } })
    }
}
