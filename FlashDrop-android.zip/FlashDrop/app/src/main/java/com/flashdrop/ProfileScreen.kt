package com.flashdrop

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** 我的资料：头像、颜色、名字（会广播给附近设备）；指纹由系统生成，不可修改。 */
@Composable
fun ProfileScreen(p: ProfileData, onSave: (String, Int, Int) -> Unit, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var name by remember { mutableStateOf(p.name) }
    var av by remember { mutableStateOf(p.avatar) }
    var col by remember { mutableStateOf(p.color) }
    Surface(Modifier.fillMaxSize(), color = cs.background) {
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(horizontal = 20.dp)) {
            TextButton(onClose) { Text("‹ 返回") }
            Text("我的资料", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(av, col, 72.dp)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(name.ifBlank { "未命名" }, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("指纹 ${fpFull(p.id)}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(name, { if (it.length <= 16) name = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("名字（最多 16 个字）") }, shape = RoundedCornerShape(14.dp))
            Spacer(Modifier.height(14.dp))
            Text("选择头像", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            LazyVerticalGrid(GridCells.Adaptive(52.dp), Modifier.fillMaxWidth().height(170.dp)) {
                items(AVATARS.size) { i ->
                    Box(Modifier.size(48.dp).clip(CircleShape).background(if (i == av) cs.primaryContainer else cs.surface)
                        .clickable { av = i }, contentAlignment = Alignment.Center) { Text(AVATARS[i], fontSize = 26.sp) }
                }
            }
            Text("选择颜色", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AVATAR_COLORS.forEachIndexed { i, c ->
                    Box(Modifier.size(38.dp).clip(CircleShape).background(c)
                        .then(if (i == col) Modifier.border(3.dp, cs.onSurface, CircleShape) else Modifier)
                        .clickable { col = i })
                }
            }
            Spacer(Modifier.height(10.dp))
            Button({ onSave(name.trim().ifBlank { p.name }, av, col) }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("保存") }
            Text("名字和头像会广播给附近的 FlashDrop 设备。指纹是本机唯一标识，即使两台手机同名也能区分；它用于区分设备，不是加密认证。",
                Modifier.padding(top = 12.dp), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
    }
}
