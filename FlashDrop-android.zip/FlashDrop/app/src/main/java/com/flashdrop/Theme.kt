package com.flashdrop

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// 品牌色取自应用图标的橙色渐变
private val Light = lightColorScheme(
    primary = Color(0xFFD9480F), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE3D6), onPrimaryContainer = Color(0xFF4A1A05),
    background = Color(0xFFF6F5F3), surface = Color(0xFFF6F5F3), onBackground = Color(0xFF1C1917), onSurface = Color(0xFF1C1917),
    surfaceVariant = Color.White, onSurfaceVariant = Color(0xFF6B645E), outline = Color(0xFFE0DBD6),
    error = Color(0xFFBA1A1A), errorContainer = Color(0xFFFBE4E0), onErrorContainer = Color(0xFF5A1710))

private val Dark = darkColorScheme(
    primary = Color(0xFFFF7A3D), onPrimary = Color(0xFF2B0E00),
    primaryContainer = Color(0xFF4A2210), onPrimaryContainer = Color(0xFFFFD9C7),
    background = Color(0xFF101010), surface = Color(0xFF101010), onBackground = Color(0xFFF1EDEA), onSurface = Color(0xFFF1EDEA),
    surfaceVariant = Color(0xFF1B1B1B), onSurfaceVariant = Color(0xFFA39C96), outline = Color(0xFF2E2B29),
    error = Color(0xFFFF8A80), errorContainer = Color(0xFF4A1F1A), onErrorContainer = Color(0xFFFFDAD4))

@Composable
fun FlashTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        shapes = Shapes(medium = RoundedCornerShape(20.dp), large = RoundedCornerShape(28.dp))
    ) { Surface(color = MaterialTheme.colorScheme.background) { content() } }
}
