package com.flashdrop

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class HistoryItem(
    val id: Long, val type: String, val sent: Boolean, val title: String, val peer: String,
    val size: Long, val time: Long, val text: String?, val uri: String?
)

fun fmtSize(b: Long) = when {
    b >= 1L shl 30 -> "%.2f GB".format(b / 1073741824.0)
    b >= 1L shl 20 -> "%.1f MB".format(b / 1048576.0)
    b >= 1024 -> "%.0f KB".format(b / 1024.0)
    else -> "$b B"
}

/** 传输历史：保存在应用私有目录，最新的在最前，最多 300 条。 */
class History(ctx: Context) {
    private val file = File(ctx.filesDir, "history.json")
    val items = MutableStateFlow(load())

    private fun load(): List<HistoryItem> = runCatching {
        val a = JSONArray(file.readText())
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            HistoryItem(o.getLong("id"), o.getString("type"), o.getBoolean("sent"), o.getString("title"), o.getString("peer"),
                o.getLong("size"), o.getLong("time"), o.optString("text").ifEmpty { null }, o.optString("uri").ifEmpty { null })
        }
    }.getOrDefault(emptyList())

    @Synchronized fun add(list: List<HistoryItem>) {
        if (list.isEmpty()) return
        val now = System.currentTimeMillis()
        val fresh = list.mapIndexed { i, h -> h.copy(id = now * 1000 + i) }
        items.value = (fresh + items.value).take(300)
        save()
    }
    @Synchronized fun delete(id: Long) { items.value = items.value.filter { it.id != id }; save() }
    @Synchronized fun clear() { items.value = emptyList(); save() }

    private fun save() = runCatching {
        val a = JSONArray()
        items.value.forEach { h ->
            a.put(JSONObject().put("id", h.id).put("type", h.type).put("sent", h.sent).put("title", h.title)
                .put("peer", h.peer).put("size", h.size).put("time", h.time).put("text", h.text ?: "").put("uri", h.uri ?: ""))
        }
        file.writeText(a.toString())
    }
}
