package com.flashdrop

import android.content.Context
import android.os.Build
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow
import java.security.SecureRandom

val AVATARS = listOf("🦊", "🐼", "🐯", "🦁", "🐸", "🐵", "🐰", "🐻", "🐨", "🐧", "🦄", "🐙",
    "🐳", "🦉", "🐢", "🦋", "🌵", "🍀", "🍉", "🍓", "🚀", "⭐", "🔥", "⚡")
val AVATAR_COLORS = listOf(Color(0xFFFF7A3D), Color(0xFF4F9DFF), Color(0xFF34C48B), Color(0xFFB07CFF),
    Color(0xFFFF6B8A), Color(0xFFF2B33D), Color(0xFF3CC7D6), Color(0xFF8E9BAE))

/** 内置表情库 */
val EMOJI_CATS: List<Pair<String, List<String>>> = listOf(
    "😀" to "😀😃😄😁😆😅😂🤣😊😇🙂😉😍🥰😘😋😛😜🤪🤗🤔😐😴😎🤓😢😭😤😡🥳🤯😱😬🙄😏".codePointsList(),
    "👍" to "👍👎👌🤞🤟🤘👏🙌🙏💪👋🤝👀🧠👆👇👈👉✋🤙".codePointsList(),
    "❤" to "❤🧡💛💚💙💜🖤🤍💔💕💖💗💘💝✨🌟💫🔥🎉🎊💯".codePointsList(),
    "🐶" to "🐶🐱🐭🐹🐰🦊🐻🐼🐨🐯🦁🐮🐷🐸🐵🐔🐧🐦🦉🐺🐴🦄🐝🦋🐢🐙🐬🐳".codePointsList(),
    "🍔" to "🍎🍊🍋🍌🍉🍇🍓🍑🍍🥭🍔🍟🍕🌭🍿🍩🍪🎂🍰🍫🍺☕🍵🥤🍜🍣".codePointsList(),
    "⚽" to "⚽🏀🏈🎮🎧🎵📷💡📱💻🔔🎁🚀✈🚗🏠⏰📌✅❌⚠❓❗".codePointsList()
)
private fun String.codePointsList(): List<String> =
    codePoints().toArray().map { String(Character.toChars(it)) }

data class ProfileData(val id: String, val name: String, val avatar: Int, val color: Int)

/** 本机资料。id 是首次启动随机生成并永久保存的设备指纹，同名设备也能区分。 */
class Profile(ctx: Context) {
    private val sp = ctx.getSharedPreferences("flashdrop", Context.MODE_PRIVATE)
    val data = MutableStateFlow(load())

    private fun load(): ProfileData {
        val id = sp.getString("id", null) ?: run {
            val b = ByteArray(8); SecureRandom().nextBytes(b)
            b.joinToString("") { "%02x".format(it) }.also { sp.edit().putString("id", it).apply() }
        }
        val h = id.hashCode() and 0x7fffffff
        return ProfileData(id, sp.getString("name", null) ?: Build.MODEL.take(16),
            sp.getInt("avatar", h % AVATARS.size), sp.getInt("color", (h / 7) % AVATAR_COLORS.size))
    }
    fun save(name: String, avatar: Int, color: Int) {
        sp.edit().putString("name", name).putInt("avatar", avatar).putInt("color", color).apply()
        data.value = data.value.copy(name = name, avatar = avatar, color = color)
    }
}

fun fp(id: String) = id.take(4).uppercase()
fun fpFull(id: String) = id.chunked(4).joinToString(" ").uppercase()
fun hexToBytes(h: String) = ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

/** 按 UTF-8 字节数截断，不会截断到字符中间 */
fun fitUtf8(s: String, max: Int): String {
    var n = 0; var i = 0; val sb = StringBuilder()
    while (i < s.length) {
        val cp = s.codePointAt(i); val str = String(Character.toChars(cp)); val b = str.toByteArray().size
        if (n + b > max) break
        sb.append(str); n += b; i += Character.charCount(cp)
    }
    return sb.toString()
}
