package com.flashdrop

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun Avatar(avatar: Int, color: Int, size: Dp, gray: Boolean = false) {
    val c = AVATAR_COLORS[color.mod(AVATAR_COLORS.size)]
    Box(Modifier.size(size).clip(CircleShape).background(if (gray) c.copy(alpha = 0.3f) else c), contentAlignment = Alignment.Center) {
        Text(AVATARS[avatar.mod(AVATARS.size)], fontSize = (size.value * 0.5f).sp, modifier = Modifier.alpha(if (gray) 0.45f else 1f))
    }
}

@Composable
fun Radar(size: Dp) {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "p")
    val c = MaterialTheme.colorScheme.primary
    Canvas(Modifier.size(size)) {
        val r = this.size.minDimension / 2
        for (i in 0..2) {
            val q = (p + i / 3f) % 1f
            drawCircle(c.copy(alpha = (1f - q) * 0.35f), radius = r * (0.35f + 0.65f * q), style = Stroke(2.dp.toPx()))
        }
        drawCircle(c, radius = r * 0.32f)
        val s = r * 0.32f; val m = center
        val tri = Path().apply {
            moveTo(m.x - s * 0.30f, m.y - s * 0.55f); lineTo(m.x + s * 0.60f, m.y)
            lineTo(m.x - s * 0.30f, m.y + s * 0.55f); close()
        }
        drawPath(tri, Color.White)
    }
}

@Composable
fun Bars(rssi: Int) {
    val lvl = when { rssi > -60 -> 4; rssi > -70 -> 3; rssi > -82 -> 2; else -> 1 }
    val on = MaterialTheme.colorScheme.primary; val off = MaterialTheme.colorScheme.outline
    Canvas(Modifier.size(22.dp, 16.dp)) {
        val bw = size.width / 4f * 0.7f
        for (i in 0..3) {
            val h = size.height * (i + 1) / 4f
            drawRoundRect(if (i < lvl) on else off, Offset(i * size.width / 4f, size.height - h), Size(bw, h), CornerRadius(2.dp.toPx()))
        }
    }
}

@Composable
fun Segment(labels: List<String>, selected: Int, enabled: List<Boolean>, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.outline.copy(alpha = 0.35f)).padding(4.dp)) {
        labels.forEachIndexed { i, l ->
            val sel = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if (sel) cs.primary else Color.Transparent)
                    .clickable(enabled = enabled[i]) { onSelect(i) }.padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) { Text(l, fontWeight = FontWeight.SemiBold, color = if (sel) cs.onPrimary else cs.onSurface.copy(alpha = if (enabled[i]) 1f else 0.4f)) }
        }
    }
}

@Composable
fun Banner(msg: String, action: String, onAction: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(Modifier.fillMaxWidth().padding(bottom = 10.dp), shape = MaterialTheme.shapes.medium, color = cs.errorContainer) {
        Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(msg, Modifier.weight(1f), color = cs.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
            TextButton(onAction) { Text(action, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun FDialog(title: String, confirm: String, onConfirm: () -> Unit, dismiss: String? = null,
            onDismiss: () -> Unit = {}, body: @Composable () -> Unit) {
    AlertDialog(
        onDismissRequest = {}, shape = RoundedCornerShape(28.dp),
        title = { Text(title, fontWeight = FontWeight.Bold) }, text = body,
        confirmButton = { Button(onConfirm, shape = RoundedCornerShape(14.dp)) { Text(confirm) } },
        dismissButton = dismiss?.let { d -> @Composable { TextButton(onDismiss) { Text(d) } } })
}

@Composable
fun ProgressBody(frac: Float, line1: String, line2: String) {
    val cs = MaterialTheme.colorScheme
    val f = frac.coerceIn(0f, 1f)
    Column {
        Text("${(f * 100).toInt()}%", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = cs.primary)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator({ f }, Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)), trackColor = cs.outline)
        Spacer(Modifier.height(12.dp))
        Text(line1, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(line2, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
    }
}

@Composable
fun CheckBadge() {
    Box(Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
        Text("✓", color = MaterialTheme.colorScheme.onPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    }
}

/** 内置表情面板 */
@Composable
fun EmojiPanel(onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var cat by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
            EMOJI_CATS.forEachIndexed { i, c ->
                Box(Modifier.clip(RoundedCornerShape(10.dp)).background(if (i == cat) cs.primaryContainer else Color.Transparent)
                    .clickable { cat = i }.padding(horizontal = 14.dp, vertical = 6.dp)) { Text(c.first, fontSize = 20.sp) }
            }
        }
        LazyVerticalGrid(GridCells.Adaptive(44.dp), Modifier.fillMaxWidth().height(176.dp)) {
            items(EMOJI_CATS[cat].second) { e ->
                Box(Modifier.size(44.dp).clickable { onPick(e) }, contentAlignment = Alignment.Center) { Text(e, fontSize = 24.sp) }
            }
        }
    }
}

/** 一条记录。showName=true 时显示对方名字，点击名字可查看与该设备的全部记录。 */
@Composable
fun RecordRow(h: HistoryItem, name: String, showName: Boolean, onName: () -> Unit, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val tf = remember { SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()) }
    Surface(Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).clickable(onClick = onClick),
        shape = MaterialTheme.shapes.medium, color = cs.surfaceVariant, border = BorderStroke(1.dp, cs.outline)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
                Text(if (h.sent) "↑" else "↓", color = cs.onPrimaryContainer, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(h.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val sub = MaterialTheme.typography.bodySmall
                    Text(if (h.type == "file") "文件 · " else "文字 · ", style = sub, color = cs.onSurfaceVariant)
                    if (showName) {
                        Text(if (h.sent) "发给 " else "来自 ", style = sub, color = cs.onSurfaceVariant)
                        Text(name, style = sub, color = cs.primary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false).clickable(onClick = onName).padding(vertical = 4.dp))
                    }
                    Text(" · ${tf.format(Date(h.time))} · ${fmtSize(h.size)}", style = sub, color = cs.onSurfaceVariant, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun RecordDetail(h: HistoryItem, name: String, onDismiss: () -> Unit, onDelete: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val tf = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }
    AlertDialog(
        onDismissRequest = onDismiss, shape = RoundedCornerShape(28.dp),
        title = { Text(if (h.type == "text") "文字内容" else h.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column {
                Text("${if (h.sent) "发给" else "来自"} $name · ${tf.format(Date(h.time))} · ${fmtSize(h.size)}",
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                if (h.type == "text") SelectionContainer {
                    Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) { Text(h.text ?: h.title) }
                } else if (!h.sent) Text("保存位置：下载/FlashDrop")
            }
        },
        confirmButton = {
            Button({
                if (h.type == "text") {
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("FlashDrop", h.text ?: h.title))
                    Toast.makeText(ctx, "已复制", Toast.LENGTH_SHORT).show()
                } else runCatching {
                    val u = Uri.parse(h.uri)
                    ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, ctx.contentResolver.getType(u) ?: "*/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
                }.onFailure { Toast.makeText(ctx, "无法打开，文件可能已被移动或删除", Toast.LENGTH_LONG).show() }
            }, shape = RoundedCornerShape(14.dp)) { Text(if (h.type == "text") "一键复制" else "打开") }
        },
        dismissButton = { TextButton(onDelete) { Text("删除记录", color = cs.error) } })
}
