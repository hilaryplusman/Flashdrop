package com.flashdrop

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Contact(val id: String, val name: String, val avatar: Int, val color: Int, val alias: String, val lastSeen: Long)

/** 见过的设备（按指纹区分）：离线后保留在“离线设备”里，可设置备注名。 */
class Contacts(ctx: Context) {
    private val file = File(ctx.filesDir, "contacts.json")
    val items = MutableStateFlow(load())

    private fun load(): List<Contact> = runCatching {
        val a = JSONArray(file.readText())
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Contact(o.getString("id"), o.getString("name"), o.getInt("avatar"), o.getInt("color"), o.optString("alias"), o.getLong("lastSeen"))
        }
    }.getOrDefault(emptyList())

    /** full=true 表示名字是完整的（来自握手）；广播里的名字可能被截断。 */
    @Synchronized fun seen(id: String, name: String, avatar: Int, color: Int, full: Boolean = false) {
        val now = System.currentTimeMillis()
        val old = items.value.find { it.id == id }
        val nm = if (!full && old != null && old.name.startsWith(name) && name.length < old.name.length) old.name else name
        val c = Contact(id, nm, avatar, color, old?.alias ?: "", now)
        if (old == null || old.name != c.name || old.avatar != c.avatar || old.color != c.color || now - old.lastSeen > 30_000) {
            items.value = items.value.filter { it.id != id } + c
            save()
        }
    }
    @Synchronized fun setAlias(id: String, alias: String) {
        items.value = items.value.map { if (it.id == id) it.copy(alias = alias.trim()) else it }
        save()
    }
    fun display(id: String, fallback: String): String =
        items.value.find { it.id == id }?.let { it.alias.ifBlank { it.name } } ?: fallback

    private fun save() = runCatching {
        val a = JSONArray()
        items.value.forEach { c ->
            a.put(JSONObject().put("id", c.id).put("name", c.name).put("avatar", c.avatar).put("color", c.color)
                .put("alias", c.alias).put("lastSeen", c.lastSeen))
        }
        file.writeText(a.toString())
    }
}
