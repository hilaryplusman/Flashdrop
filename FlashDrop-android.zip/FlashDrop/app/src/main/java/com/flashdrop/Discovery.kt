package com.flashdrop

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.UUID

data class Peer(val id: String, val name: String, val rssi: Int, val lastSeen: Long)

/** 同时广播自己并扫描同样带有 FlashDrop 服务 UUID 的设备。 */
@SuppressLint("MissingPermission") // 权限在 MainActivity 中先行申请
class Discovery(ctx: Context) {
    companion object {
        val SERVICE: UUID = UUID.fromString("7f1a5d00-6c4e-4b8a-9d3e-f1a5d0c0de01")
        const val EXPIRE_MS = 8_000L
    }
    private val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    val peers = MutableStateFlow<List<Peer>>(emptyList())
    private val map = HashMap<String, Peer>()
    private var pruner: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    val status = MutableStateFlow("")
    val enabled get() = adapter?.isEnabled == true
    private val adCb = object : AdvertiseCallback() {
        override fun onStartSuccess(s: AdvertiseSettings) { status.value = "" }
        override fun onStartFailure(code: Int) { status.value = "广播失败（$code）" }
    }
    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val name = r.scanRecord?.deviceName ?: synchronized(map) { map[r.device.address]?.name } ?: "FlashDrop 设备"
            synchronized(map) { map[r.device.address] = Peer(r.device.address, name, r.rssi, System.currentTimeMillis()) }
            publish()
        }
    }

    private fun publish() = synchronized(map) { peers.value = map.values.sortedByDescending { it.rssi } }

    fun start() {
        stop()
        if (adapter == null || !adapter.isEnabled) return
        adapter.bluetoothLeAdvertiser?.startAdvertising(
            AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setConnectable(true).setTimeout(0).build(),
            AdvertiseData.Builder().addServiceUuid(ParcelUuid(SERVICE)).setIncludeDeviceName(false).build(),
            AdvertiseData.Builder().setIncludeDeviceName(true).build(), // 名字放在扫描响应里
            adCb
        )
        adapter.bluetoothLeScanner?.startScan(
            listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE)).build()),
            ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),
            scanCb
        )
        pruner = scope.launch {
            while (isActive) {
                delay(2_000)
                val now = System.currentTimeMillis()
                synchronized(map) { map.values.removeAll { now - it.lastSeen > EXPIRE_MS } }
                publish()
            }
        }
    }

    fun stop() {
        runCatching { adapter?.bluetoothLeAdvertiser?.stopAdvertising(adCb) }
        runCatching { adapter?.bluetoothLeScanner?.stopScan(scanCb) }
        pruner?.cancel()
        synchronized(map) { map.clear() }; publish()
    }
}
