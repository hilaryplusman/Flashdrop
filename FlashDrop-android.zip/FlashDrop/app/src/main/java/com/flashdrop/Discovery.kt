package com.flashdrop

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.UUID

data class Peer(val id: String, val addr: String, val name: String, val avatar: Int, val color: Int,
                val rssi: Int, val lastSeen: Long, val since: Long)

/**
 * 广播：服务 UUID + 扫描响应里的厂商数据 [指纹 8 字节][头像 1][颜色 1][名字 ≤16 字节]。
 * 设备按“指纹”区分（蓝牙地址会轮换），所以同名手机也不会混淆。
 */
@SuppressLint("MissingPermission")
class Discovery(ctx: Context, private val profile: Profile, private val contacts: Contacts) {
    companion object {
        val SERVICE: UUID = UUID.fromString("7f1a5d00-6c4e-4b8a-9d3e-f1a5d0c0de01")
        const val EXPIRE_MS = 10_000L
        const val MFG = 0xFFFF
    }
    private val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    val peers = MutableStateFlow<List<Peer>>(emptyList())
    val status = MutableStateFlow("")
    val enabled get() = adapter?.isEnabled == true
    private val map = HashMap<String, Peer>()
    private var pruner: Job? = null
    private var lastKey = ""
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    fun addressOf(id: String): String? = synchronized(map) { map[id]?.addr }

    private val adCb = object : AdvertiseCallback() {
        override fun onStartSuccess(s: AdvertiseSettings) { status.value = "" }
        override fun onStartFailure(code: Int) { status.value = "广播失败（$code）" }
    }
    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val md = r.scanRecord?.getManufacturerSpecificData(MFG) ?: return
            if (md.size < 10) return
            val id = md.copyOfRange(0, 8).joinToString("") { "%02x".format(it) }
            if (id == profile.data.value.id) return
            val avatar = md[8].toInt() and 0xFF; val color = md[9].toInt() and 0xFF
            val name = String(md, 10, md.size - 10, Charsets.UTF_8)
            val now = System.currentTimeMillis()
            synchronized(map) {
                val old = map[id]
                val rssi = if (old == null) r.rssi else (old.rssi * 3 + r.rssi) / 4   // 平滑信号
                map[id] = Peer(id, r.device.address, name, avatar, color, rssi, now, old?.since ?: now)
            }
            contacts.seen(id, name, avatar, color)
            publish()
        }
    }

    private fun level(r: Int) = when { r > -60 -> 4; r > -70 -> 3; r > -82 -> 2; else -> 1 }
    /** 按首次发现的先后固定排序；只有设备增减、改名或信号格数变化时才刷新界面。 */
    private fun publish() = synchronized(map) {
        val list = map.values.sortedWith(compareBy({ it.since }, { it.id }))
        val key = list.joinToString(",") { "${it.id}|${it.name}|${it.avatar}|${it.color}|${level(it.rssi)}" }
        if (key != lastKey) { lastKey = key; peers.value = list }
    }

    private fun payload(): ByteArray {
        val p = profile.data.value
        return hexToBytes(p.id) + byteArrayOf(p.avatar.toByte(), p.color.toByte()) + fitUtf8(p.name, 16).toByteArray()
    }

    /** 暂停：停止广播和扫描，但保留设备列表（传输期间使用，避免射频冲突导致卡顿）。 */
    fun pause() {
        runCatching { adapter?.bluetoothLeAdvertiser?.stopAdvertising(adCb) }
        runCatching { adapter?.bluetoothLeScanner?.stopScan(scanCb) }
        pruner?.cancel()
    }

    /** 开始或恢复。已知设备给一次宽限，避免恢复瞬间闪成离线。 */
    fun start() {
        pause()
        if (!enabled) return
        val now = System.currentTimeMillis()
        synchronized(map) { map.replaceAll { _, v -> v.copy(lastSeen = now) } }
        adapter.bluetoothLeAdvertiser?.startAdvertising(
            AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setConnectable(true).setTimeout(0).build(),
            AdvertiseData.Builder().addServiceUuid(ParcelUuid(SERVICE)).setIncludeDeviceName(false).build(),
            AdvertiseData.Builder().addManufacturerData(MFG, payload()).setIncludeDeviceName(false).build(),
            adCb)
        adapter.bluetoothLeScanner?.startScan(
            listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE)).build()),
            ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCb)
        pruner = scope.launch {
            while (isActive) {
                delay(2_000)
                val t = System.currentTimeMillis()
                synchronized(map) { map.values.removeAll { t - it.lastSeen > EXPIRE_MS } }
                publish()
            }
        }
    }

    fun stop() { pause(); synchronized(map) { map.clear() }; publish() }
}
