package com.flashdrop

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.net.wifi.p2p.*
import android.net.wifi.p2p.WifiP2pManager.ActionListener
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.os.Looper
import android.provider.MediaStore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.UUID

data class Item(val uri: Uri, val name: String, val size: Long)

sealed interface UiState {
    object Idle : UiState
    data class Waiting(val peer: String, val stage: String = "正在连接蓝牙…") : UiState
    data class Incoming(val count: Int, val total: Long, val first: String, val from: String = "") : UiState
    data class Progress(val sending: Boolean, val name: String, val done: Long, val total: Long, val speed: Double) : UiState
    data class Done(val sending: Boolean) : UiState
    data class Failed(val msg: String) : UiState
    data class TextIncoming(val bytes: Int) : UiState
    data class TextProgress(val sending: Boolean, val done: Int, val total: Int) : UiState
    data class TextReceived(val text: String, val from: String = "") : UiState
    object TextSent : UiState
}

/**
 * 控制消息（提议/应答/组凭据）和文字只走 BLE；文件数据只走 Wi-Fi Direct + TCP。
 * 可靠性（用户无感）：
 *  - 文字：分块带偏移量，断线或卡住后自动重连，由接收方告知已收位置，从断点继续；
 *  - 文件：TCP 中断后发送方自动重连，接收方回报每个文件已收字节数，断点续传，校验失败自动重传。
 */
@SuppressLint("MissingPermission")
class Transfer(private val ctx: Context, private val history: History, private val profile: Profile, private val contacts: Contacts) {
    companion object {
        val CTRL: UUID = UUID.fromString("7f1a5d01-6c4e-4b8a-9d3e-f1a5d0c0de01")
        val TEXT: UUID = UUID.fromString("7f1a5d02-6c4e-4b8a-9d3e-f1a5d0c0de01")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        const val MAX_TEXT = 100 * 1024
        const val PORT = 8988
        const val GO_IP = "192.168.49.1"
    }

    val state = MutableStateFlow<UiState>(UiState.Idle)
    val busy get() = state.value.let {
        it is UiState.Waiting || it is UiState.Progress || it is UiState.Incoming ||
            it is UiState.TextIncoming || it is UiState.TextProgress
    }
    /** 文件会话进行中：此时禁止发送/接收文字 */
    val fileLocked get() = busy && mode == "file"

    private val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val p2p = ctx.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
    private val chan = p2p.initialize(ctx, Looper.getMainLooper(), null)
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var server: BluetoothGattServer? = null
    private var ctrl: BluetoothGattCharacteristic? = null
    private var remote: BluetoothDevice? = null
    private var gatt: BluetoothGatt? = null
    private var job: Job? = null
    private var closer: Closeable? = null
    private var closer2: Closeable? = null
    @Volatile private var cancelled = false
    private var files: List<Item> = emptyList()
    private var offer = ""
    private var mode = ""
    private var peerName = ""
    private var peerId = ""
    private class Remote(val id: String, val name: String, val avatar: Int, val color: Int)
    private val remotes = HashMap<String, Remote>()   // 蓝牙地址 -> 对方自报身份（握手）
    private var hsStep = 0
    private var wl: PowerManager.WakeLock? = null
    private var wfl: WifiManager.WifiLock? = null
    private fun lock() = runCatching {   // 文件传输期间防止系统省电造成断流
        wl = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FlashDrop:xfer")
            .apply { acquire(30 * 60 * 1000L) }
        wfl = (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "FlashDrop:wifi").apply { acquire() }
    }
    private fun unlock() {
        runCatching { wl?.takeIf { it.isHeld }?.release() }; runCatching { wfl?.takeIf { it.isHeld }?.release() }
        wl = null; wfl = null
    }
    private var peerDev: BluetoothDevice? = null
    private var retries = 0
    private var watchdog: Job? = null
    private var discStarted = false
    private var stageAt = 0L
    private val WIFI_STAGE = "对方已接受，正在建立 Wi-Fi Direct…"
    private val WAIT_STAGE = "等待对方回应…"

    private fun stage(t: String) {
        val s = state.value
        if (s is UiState.Waiting) { state.value = s.copy(stage = t); stageAt = System.currentTimeMillis() }
    }
    private fun discover(g: BluetoothGatt) { if (discStarted) return; discStarted = true; g.discoverServices() }
    private fun remoteNow(): Remote? = remote?.let { remotes[it.address] }
    private fun peerLabel(): String = remoteNow()?.let { contacts.display(it.id, it.name) }
        ?: runCatching { remote?.name }.getOrNull() ?: "附近设备"
    private fun peerIdNow() = remoteNow()?.id ?: ""

    private fun connect(dev: BluetoothDevice) {
        peerDev = dev; retries = 0; discStarted = false; hsStep = 0
        gatt = dev.connectGatt(ctx, false, cliCb, BluetoothDevice.TRANSPORT_LE)
        stageAt = System.currentTimeMillis()
        watchdog?.cancel()
        watchdog = scope.launch {
            while (isActive) {
                delay(1000)
                val w = state.value as? UiState.Waiting ?: break
                // 文件提议在等对方点“接收”给 90 秒；建立 Wi-Fi Direct 给 60 秒；其余（含文字）25 秒
                val limit = when {
                    w.stage == WAIT_STAGE && mode == "file" -> 90_000
                    w.stage == WIFI_STAGE -> 60_000
                    else -> 25_000
                }
                if (System.currentTimeMillis() - stageAt > limit) {
                    fail(IOException("连接超时（卡在：${w.stage}）。请确认对方已打开 FlashDrop 且在前台")); cleanup(); break
                }
            }
        }
    }

    // ───────────── 接收方：GATT 服务 ─────────────
    fun startServer() {
        stopServer()
        val ch = BluetoothGattCharacteristic(CTRL,
            BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_NOTIFY,
            BluetoothGattCharacteristic.PERMISSION_WRITE)
        ch.addDescriptor(BluetoothGattDescriptor(CCCD, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE))
        val svc = BluetoothGattService(Discovery.SERVICE, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        svc.addCharacteristic(ch)
        svc.addCharacteristic(BluetoothGattCharacteristic(TEXT, BluetoothGattCharacteristic.PROPERTY_WRITE, BluetoothGattCharacteristic.PERMISSION_WRITE))
        ctrl = ch
        server = bm.openGattServer(ctx, srvCb)?.also { it.addService(svc) }
    }
    fun stopServer() { runCatching { server?.close() }; server = null }

    private val srvCb = object : BluetoothGattServerCallback() {
        override fun onCharacteristicWriteRequest(d: BluetoothDevice, id: Int, c: BluetoothGattCharacteristic,
                                                  prep: Boolean, resp: Boolean, off: Int, v: ByteArray) {
            if (resp) server?.sendResponse(d, id, BluetoothGatt.GATT_SUCCESS, 0, null)
            if (c.uuid == TEXT) { if (d.address == remote?.address) onTextChunk(v); return }
            val p = String(v).split("|", limit = 4)
            when {
                p[0] == "HELLO" -> {
                    val q = String(v).split("|", limit = 5)
                    if (q.size >= 5) {
                        val r = Remote(q[1], q[4], q[2].toIntOrNull() ?: 0, q[3].toIntOrNull() ?: 0)
                        remotes[d.address] = r; contacts.seen(r.id, r.name, r.avatar, r.color, full = true)
                    }
                }
                p[0] == "OFFER" && p.size >= 4 -> {
                    if (busy || state.value !is UiState.Idle) notifyTo(d, "REJECT")
                    else {
                        mode = "file"; remote = d
                        state.value = UiState.Incoming(p[1].toIntOrNull() ?: 0, p[2].toLongOrNull() ?: 0, p[3], peerLabel())
                    }
                }
                p[0] == "TXTOFFER" && p.size >= 2 -> {
                    val n = p[1].toIntOrNull() ?: -1
                    val sid = p.getOrNull(2) ?: ""
                    val s = state.value
                    when {
                        // 已完整收到：发送方没收到确认而重连，直接再确认一次
                        sid.isNotEmpty() && sid == rxDoneSid -> notifyTo(d, "TXTDONE")
                        // 断线重连：告知已收位置，从断点继续
                        mode == "text" && sid.isNotEmpty() && sid == rxSid && s is UiState.TextProgress && !s.sending -> {
                            remote = d; lastRx = System.currentTimeMillis(); notifyTo(d, "TXTOK|${rx.size()}")
                        }
                        busy || s !is UiState.Idle || n !in 1..MAX_TEXT -> notifyTo(d, "REJECT")
                        else -> { remote = d; mode = "text"; rx.reset(); rxExpect = n; rxSid = sid; acceptText() }
                    }
                }
                p[0] == "TXTEND" && p.size >= 2 && d.address == remote?.address -> finishText(p[1])
            }
        }
        override fun onConnectionStateChange(d: BluetoothDevice, st: Int, ns: Int) {
            // 发送方在对方点击前取消了；文字接收中断线不报错，等待发送方自动重连
            if (ns == BluetoothProfile.STATE_DISCONNECTED && state.value is UiState.Incoming && d.address == remote?.address)
                state.value = UiState.Idle
        }
        override fun onDescriptorWriteRequest(d: BluetoothDevice, id: Int, desc: BluetoothGattDescriptor,
                                              prep: Boolean, resp: Boolean, off: Int, v: ByteArray) {
            if (resp) server?.sendResponse(d, id, BluetoothGatt.GATT_SUCCESS, 0, null)
        }
    }

    private fun notifyPeer(msg: String) = notifyTo(remote, msg)
    private fun notifyTo(d: BluetoothDevice?, msg: String) {
        val c = ctrl ?: return; val dev = d ?: return
        if (Build.VERSION.SDK_INT >= 33) server?.notifyCharacteristicChanged(dev, c, false, msg.toByteArray())
        else { c.value = msg.toByteArray(); server?.notifyCharacteristicChanged(dev, c, false) }
    }

    fun decline() { notifyPeer("REJECT"); state.value = UiState.Idle }

    // ───────────── 文字（接收） ─────────────
    private val rx = ByteArrayOutputStream()
    private var rxExpect = 0
    private var rxSid = ""
    private var rxDoneSid = ""
    private var lastRx = 0L
    private var rxWatch: Job? = null

    fun acceptText() {
        state.value = UiState.TextProgress(false, 0, rxExpect)
        lastRx = System.currentTimeMillis()
        rxWatch?.cancel()
        rxWatch = scope.launch {   // 30 秒收不到任何数据（含重连）才报错
            while (isActive) {
                delay(1000)
                val s = state.value
                if (!(s is UiState.TextProgress && !s.sending)) break
                if (System.currentTimeMillis() - lastRx > 30_000) {
                    rx.reset(); state.value = UiState.Failed("接收中断：超过 30 秒没有收到数据"); break
                }
            }
        }
        notifyPeer("TXTOK|0")
    }

    private fun onTextChunk(v: ByteArray) {
        if (mode != "text" || state.value !is UiState.TextProgress || v.size < 4) return
        lastRx = System.currentTimeMillis()
        val off = ByteBuffer.wrap(v, 0, 4).int
        if (off != rx.size()) return   // 重复或乱序：忽略，发送方会按我方进度重发
        rx.write(v, 4, v.size - 4)
        if (rx.size() > rxExpect) { state.value = UiState.Failed("文本长度异常"); return }
        state.value = UiState.TextProgress(false, rx.size(), rxExpect)
    }

    private fun finishText(hash: String) {
        if (mode != "text" || state.value !is UiState.TextProgress) return
        val b = rx.toByteArray()
        if (b.size == rxExpect && hex(b) == hash) {
            rx.reset(); rxDoneSid = rxSid
            val text = String(b, Charsets.UTF_8)
            recordText(false, peerLabel(), text, peerIdNow())
            notifyPeer("TXTDONE"); state.value = UiState.TextReceived(text, peerLabel())
        } else { rx.reset(); notifyPeer("TXTBAD"); state.value = UiState.Failed("文本校验失败") }
    }

    private fun recordText(sent: Boolean, who: String, text: String, pid: String) {
        val title = text.lineSequence().firstOrNull { it.isNotBlank() }?.trim()?.take(60) ?: "（空白）"
        history.add(listOf(HistoryItem(0, "text", sent, title, who, text.toByteArray().size.toLong(),
            System.currentTimeMillis(), text.take(30_000), null, pid)))
    }
    private fun hex(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    // ───────────── 文件（接收） ─────────────
    private class RxFile(val name: String, val size: Long) { var uri: Uri? = null; var have = 0L; var done = false }
    private var rxFiles: List<RxFile> = emptyList()

    fun accept() {
        cancelled = false; rxFiles = emptyList(); lock()
        state.value = UiState.Progress(false, "", 0, 1, 0.0)
        job = scope.launch {
            try {
                var created = false
                for (i in 0 until 3) {   // 自动重试创建 Wi-Fi Direct 组
                    act { p2p.removeGroup(chan, it) }
                    if (act { p2p.createGroup(chan, it) }) { created = true; break }
                    delay(1200)
                }
                if (!created) throw IOException("无法创建 Wi-Fi Direct 连接，请确认 Wi-Fi 已开启")
                var g: WifiP2pGroup? = null
                for (i in 0 until 10) { g = groupInfo(); if (g != null) break; delay(300) }
                val grp = g ?: throw IOException("读取 Wi-Fi Direct 组信息失败")
                if (grp.passphrase.isNullOrEmpty()) throw IOException("无法获取 Wi-Fi Direct 密码")
                val ss = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(PORT)) }
                closer2 = ss
                notifyPeer("ACCEPT|${grp.networkName}|${grp.passphrase}")
                var finished = false
                while (!finished) {
                    ss.soTimeout = 45_000
                    val s = try { ss.accept() } catch (e: SocketTimeoutException) {
                        throw IOException(if (rxFiles.isEmpty()) "等待对方连接超时" else "传输中断，对方未能重新连接")
                    }
                    s.soTimeout = 30_000; s.keepAlive = true; s.tcpNoDelay = true
                    closer = s
                    try { s.use { receive(it) }; finished = true }
                    catch (e: IOException) { if (cancelled) throw e }   // 不打扰用户，等发送方重连后断点续传
                }
                val who = peerLabel(); val pid = peerIdNow(); val now = System.currentTimeMillis()
                history.add(rxFiles.filter { it.done }.map { HistoryItem(0, "file", false, it.name, who, it.size, now, null, it.uri?.toString(), pid) })
                state.value = UiState.Done(false)
            } catch (e: Exception) { fail(e) } finally { cleanup() }
        }
    }

    private fun receive(s: Socket) {
        val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 65536))
        val out = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
        val n = inp.readInt()
        if (n !in 1..10_000) throw IOException("协议错误")
        val names = ArrayList<String>(); val sizes = ArrayList<Long>()
        repeat(n) { names += inp.readUTF(); sizes += inp.readLong() }
        // 同一批文件重连：保留已收部分；否则重新开始
        if (rxFiles.size != n || rxFiles.indices.any { rxFiles[it].name != names[it] || rxFiles[it].size != sizes[it] })
            rxFiles = List(n) { RxFile(names[it], sizes[it]) }
        // 握手：告知发送方每个文件已收字节数（-1 表示已校验完成）
        rxFiles.forEach { out.writeLong(if (it.done) -1L else it.have) }
        out.flush()

        val total = sizes.sum().coerceAtLeast(1)
        var done = rxFiles.sumOf { if (it.done) it.size else it.have }
        val base = done; val t0 = System.currentTimeMillis(); var last = 0L
        val buf = ByteArray(65536)
        for (f in rxFiles) {
            if (f.done) continue
            val md = MessageDigest.getInstance("SHA-256")
            val safe = f.name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            var uri = f.uri
            if (uri == null) {
                uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safe)
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/FlashDrop")
                }) ?: throw IOException("无法创建文件")
                f.uri = uri; f.have = 0
            } else if (f.have > 0) {   // 重新计算已收部分的校验
                var left = f.have
                ctx.contentResolver.openInputStream(uri)?.use { ins ->
                    while (left > 0) {
                        val r = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt()); if (r < 0) break
                        md.update(buf, 0, r); left -= r
                    }
                }
            }
            ctx.contentResolver.openOutputStream(uri, if (f.have > 0) "wa" else "w")!!.use { o ->
                var left = f.size - f.have
                while (left > 0) {
                    val r = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (r < 0) throw EOFException("连接中断")
                    o.write(buf, 0, r); md.update(buf, 0, r); left -= r; f.have += r; done += r
                    val now = System.currentTimeMillis()
                    if (now - last > 120) { last = now; progress(false, safe, done, total, t0, base) }
                }
            }
            val sum = ByteArray(32); inp.readFully(sum)
            if (!MessageDigest.isEqual(sum, md.digest())) {
                ctx.contentResolver.delete(uri, null, null); f.uri = null; f.have = 0
                throw IOException("$safe 校验失败，自动重传")
            }
            f.done = true
        }
        out.write(1); out.flush()
    }

    // ───────────── 发送方：BLE 握手 ─────────────
    fun send(id: String, address: String, name: String, items: List<Item>) {
        if (busy || items.isEmpty()) return
        cancelled = false; mode = "file"; files = items; peerName = name; peerId = id
        val first = items.first().name.replace("|", "_").take(60)
        offer = "OFFER|${items.size}|${items.sumOf { it.size }}|$first"
        state.value = UiState.Waiting(name)
        connect(bm.adapter.getRemoteDevice(address))
    }

    private val cliCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, ns: Int) {
            if (ns == BluetoothProfile.STATE_CONNECTED) {
                stage("已连接，协商中…")
                g.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH)
                if (!g.requestMtu(247)) discover(g) else scope.launch { delay(2000); discover(g) }
            } else if (ns == BluetoothProfile.STATE_DISCONNECTED) {
                val s = state.value
                if (s is UiState.Waiting) {
                    val d = peerDev
                    if (retries < 3 && d != null) {
                        retries++; discStarted = false; hsStep = 0; g.close(); stage("重试连接（$retries）…")
                        val cb = this
                        // 关闭后立刻重连在不少机型上会失败，稍等再连
                        scope.launch { delay(500L * retries); if (state.value is UiState.Waiting) gatt = d.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE) }
                    } else { fail(IOException("蓝牙连接失败（状态码 $st）")); cleanup() }
                } else if (sendingText()) recoverText()
            }
        }
        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, st: Int) {
            this@Transfer.mtu = if (st == BluetoothGatt.GATT_SUCCESS) mtu else 23
            discover(g)
        }
        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            stage("握手中…")
            val c = g.getService(Discovery.SERVICE)?.getCharacteristic(CTRL)
            if (c == null) { bleFail("对方不是 FlashDrop 或版本不兼容"); return }
            g.setCharacteristicNotification(c, true)
            val d = c.getDescriptor(CCCD)
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(d)
        }
        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, st: Int) {
            if (st != BluetoothGatt.GATT_SUCCESS) { bleFail("订阅通知失败（$st）"); return }
            stage(WAIT_STAGE)
            val c = d.characteristic
            val me = profile.data.value
            val nm = fitUtf8(me.name.replace("|", " "), (mtu - 3 - 30).coerceIn(8, 48))
            hsStep = 1   // 先自报身份（指纹/头像/名字），再发提议
            c.value = "HELLO|${me.id}|${me.avatar}|${me.color}|$nm".toByteArray()
            g.writeCharacteristic(c)
        }
        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) {
            if (st != BluetoothGatt.GATT_SUCCESS) { bleFail("蓝牙写入失败"); return }
            if (c.uuid == CTRL && hsStep == 1) { hsStep = 2; c.value = offer.toByteArray(); g.writeCharacteristic(c); return }
            if (c.uuid == TEXT) nextChunk(g)
        }
        // 新旧系统版本都要处理；Android 13+ 走带 value 的新回调
        @Deprecated("compat") override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) = reply(g, String(c.value))
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) = reply(g, String(value))

        private fun reply(g: BluetoothGatt, msg: String) {
            val p = msg.split("|")
            when {
                p[0] == "REJECT" -> { fail(IOException("对方已拒绝，或正忙于其他传输")); cleanup() }
                p[0] == "ACCEPT" && p.size >= 3 && job?.isActive != true -> {
                    stage(WIFI_STAGE); lock()
                    job = scope.launch { doSend(p[1], p[2]) }
                }
                p[0] == "TXTOK" -> if (!txStarted) {
                    txStarted = true
                    txPos = (p.getOrNull(1)?.toIntOrNull() ?: 0).coerceIn(0, txBytes.size)   // 接收方告知的断点
                    nextChunk(g)
                }
                p[0] == "TXTDONE" -> if (sendingText()) {
                    stallJob?.cancel(); textEpoch++
                    recordText(true, peerName, txText, peerId)
                    state.value = UiState.TextSent; cleanup()
                }
                p[0] == "TXTBAD" -> { fail(IOException("对方校验失败")); cleanup() }
            }
        }
    }

    private fun sendingText() = state.value.let { it is UiState.TextProgress && it.sending }
    private fun bleFail(msg: String) { if (sendingText()) recoverText() else { fail(IOException(msg)); cleanup() } }

    // ───────────── 文字（发送）：卡住或断线自动重连续传 ─────────────
    private var txBytes = ByteArray(0)
    private var txText = ""
    private var txPos = 0
    private var txStarted = false
    private var mtu = 23
    private var stallJob: Job? = null
    @Volatile private var textEpoch = 0
    private var textTries = 0

    fun sendText(id: String, address: String, name: String, text: String) {
        val b = text.toByteArray(Charsets.UTF_8)
        if (fileLocked) { state.value = UiState.Failed("文件传输中，暂不可发送文字"); return }
        if (busy) return
        if (b.isEmpty() || b.size > MAX_TEXT) { state.value = UiState.Failed("文本超过 100 KB，请改用文件发送"); return }
        cancelled = false; mode = "text"; peerName = name; peerId = id
        txBytes = b; txText = text; txPos = 0; txStarted = false; textTries = 0; textEpoch++
        offer = "TXTOFFER|${b.size}|${UUID.randomUUID().toString().take(8)}"
        state.value = UiState.Waiting(name)
        connect(bm.adapter.getRemoteDevice(address))
    }

    private fun armStall() {
        val mark = txPos; val epoch = textEpoch
        stallJob?.cancel()
        stallJob = scope.launch {
            delay(8_000)
            if (epoch == textEpoch && sendingText() && txPos == mark) recoverText()   // 8 秒没进展：重连续传
        }
    }

    private fun nextChunk(g: BluetoothGatt) {
        val svc = g.getService(Discovery.SERVICE)
        if (svc == null) { recoverText(); return }
        if (txPos >= txBytes.size) {
            val c = svc.getCharacteristic(CTRL)
            c.value = "TXTEND|${hex(txBytes)}".toByteArray()
            armStall()
            if (!g.writeCharacteristic(c)) recoverText()
            return
        }
        val n = minOf(mtu - 3 - 4, 176, txBytes.size - txPos)
        val c = svc.getCharacteristic(TEXT)
        c.value = ByteBuffer.allocate(4 + n).putInt(txPos).put(txBytes, txPos, n).array()
        txPos += n
        state.value = UiState.TextProgress(true, txPos, txBytes.size)
        armStall()
        if (!g.writeCharacteristic(c)) recoverText()
    }

    private fun recoverText() {
        if (cancelled || !sendingText()) return
        if (++textTries > 5) { fail(IOException("蓝牙连接多次中断，请让两台手机靠近后重试")); cleanup(); return }
        val epoch = ++textEpoch
        stallJob?.cancel()
        runCatching { gatt?.close() }; gatt = null
        discStarted = false; txStarted = false; hsStep = 0
        val dev = peerDev ?: return
        scope.launch {
            delay(600L * textTries)
            if (epoch != textEpoch || cancelled) return@launch
            gatt = dev.connectGatt(ctx, false, cliCb, BluetoothDevice.TRANSPORT_LE)
            stallJob = scope.launch { delay(12_000); if (epoch == textEpoch) recoverText() }   // 重连本身卡住就再试
        }
    }

    // ───────────── 文件（发送）：失败自动重连续传 ─────────────
    private suspend fun doSend(ssid: String, pass: String) {
        try {
            val cfg = WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass).build()
            var joined = false
            for (i in 0 until 3) {   // 自动重试加入
                if (act { p2p.connect(chan, cfg, it) }) { joined = true; break }
                act { p2p.cancelConnect(chan, it) }; delay(1500)
            }
            if (!joined) throw IOException("无法加入 Wi-Fi Direct 连接")
            var attempt = 0; var timeout = 40_000L
            while (true) {
                try { sendOnce(timeout); break }
                catch (e: IOException) {
                    if (cancelled || ++attempt > 5) throw e
                    timeout = 20_000L; delay(1000L * attempt)   // 用户无感：重新连接并从断点继续
                }
            }
            val now = System.currentTimeMillis()
            history.add(files.map { HistoryItem(0, "file", true, it.name, peerName, it.size, now, null, it.uri.toString(), peerId) })
            state.value = UiState.Done(true)
        } catch (e: Exception) { fail(e) } finally { cleanup() }
    }

    private suspend fun connectSocket(timeoutMs: Long): Socket {
        var sock: Socket? = null; val end = System.currentTimeMillis() + timeoutMs
        while (sock == null && System.currentTimeMillis() < end) {
            val t = Socket()
            try { t.connect(InetSocketAddress(GO_IP, PORT), 2000); sock = t }
            catch (e: IOException) { runCatching { t.close() }; delay(1000) }
        }
        return sock ?: throw IOException("连接对方超时")
    }

    private suspend fun sendOnce(timeoutMs: Long) {
        val s = connectSocket(timeoutMs)
        s.soTimeout = 30_000; s.keepAlive = true; s.tcpNoDelay = true
        s.use {
            closer = it
            val out = DataOutputStream(BufferedOutputStream(it.getOutputStream(), 65536))
            val inp = DataInputStream(BufferedInputStream(it.getInputStream()))
            out.writeInt(files.size)
            files.forEach { f -> out.writeUTF(f.name); out.writeLong(f.size) }
            out.flush()
            val have = LongArray(files.size) { inp.readLong() }   // 握手：对方已收多少
            val total = files.sumOf { f -> f.size }.coerceAtLeast(1)
            var done = files.indices.sumOf { i -> if (have[i] < 0) files[i].size else have[i] }
            val base = done; val t0 = System.currentTimeMillis(); var last = 0L
            val buf = ByteArray(65536)
            for ((i, f) in files.withIndex()) {
                if (have[i] < 0) continue
                val md = MessageDigest.getInstance("SHA-256")
                ctx.contentResolver.openInputStream(f.uri)!!.use { ins ->
                    var skip = have[i]
                    while (skip > 0) {   // 已发部分只参与校验，不再发送
                        val r = ins.read(buf, 0, minOf(buf.size.toLong(), skip).toInt())
                        if (r < 0) throw EOFException("读取 ${f.name} 失败")
                        md.update(buf, 0, r); skip -= r
                    }
                    var left = f.size - have[i]
                    while (left > 0) {
                        val r = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (r < 0) throw EOFException("读取 ${f.name} 失败")
                        out.write(buf, 0, r); md.update(buf, 0, r); left -= r; done += r
                        val now = System.currentTimeMillis()
                        if (now - last > 120) { last = now; progress(true, f.name, done, total, t0, base) }
                    }
                }
                out.write(md.digest())
            }
            out.flush()
            if (inp.read() != 1) throw IOException("对方校验失败")
        }
    }

    // ───────────── 公共 ─────────────
    fun cancel() {
        cancelled = true; textEpoch++
        val s = state.value
        if (s is UiState.TextProgress && !s.sending) notifyPeer("REJECT")   // 通知发送方，避免它一直等
        watchdog?.cancel(); stallJob?.cancel(); job?.cancel()
        runCatching { closer?.close() }; runCatching { closer2?.close() }
        cleanup(); state.value = UiState.Idle
    }
    fun reset() { mode = ""; state.value = UiState.Idle }

    private fun progress(sending: Boolean, name: String, done: Long, total: Long, t0: Long, base: Long = 0) {
        val sec = (System.currentTimeMillis() - t0).coerceAtLeast(1) / 1000.0
        state.value = UiState.Progress(sending, name, done, total, (done - base).coerceAtLeast(0) / sec)
    }
    private fun fail(e: Exception) {
        if (cancelled) return
        state.value = UiState.Failed(when (e) {
            is SocketTimeoutException -> "等待对方连接超时"
            is CancellationException -> return
            else -> e.message ?: "传输失败"
        })
    }
    private fun cleanup() {
        unlock()
        stallJob?.cancel(); rxWatch?.cancel()
        runCatching { closer?.close() }; closer = null
        runCatching { closer2?.close() }; closer2 = null
        runCatching { gatt?.close() }; gatt = null
        runCatching { p2p.removeGroup(chan, null) }
    }
    private suspend fun act(f: (ActionListener) -> Unit): Boolean = suspendCancellableCoroutine { c ->
        f(object : ActionListener {
            override fun onSuccess() { if (c.isActive) c.resumeWith(Result.success(true)) }
            override fun onFailure(r: Int) { if (c.isActive) c.resumeWith(Result.success(false)) }
        })
    }
    private suspend fun groupInfo(): WifiP2pGroup? = suspendCancellableCoroutine { c ->
        p2p.requestGroupInfo(chan) { if (c.isActive) c.resumeWith(Result.success(it)) }
    }
}
