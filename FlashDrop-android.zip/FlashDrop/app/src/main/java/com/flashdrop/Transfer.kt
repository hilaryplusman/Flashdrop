package com.flashdrop

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.net.wifi.p2p.*
import android.net.wifi.p2p.WifiP2pManager.ActionListener
import android.os.Build
import android.os.Looper
import android.provider.MediaStore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.UUID

data class Item(val uri: Uri, val name: String, val size: Long)

sealed interface UiState {
    object Idle : UiState
    data class Waiting(val peer: String, val stage: String = "正在连接蓝牙…") : UiState
    data class Incoming(val count: Int, val total: Long, val first: String) : UiState
    data class Progress(val sending: Boolean, val name: String, val done: Long, val total: Long, val speed: Double) : UiState
    data class Done(val sending: Boolean) : UiState
    data class Failed(val msg: String) : UiState
    data class TextIncoming(val bytes: Int) : UiState
    data class TextProgress(val sending: Boolean, val done: Int, val total: Int) : UiState
    data class TextReceived(val text: String) : UiState
    object TextSent : UiState
}

/**
 * 流程：BLE GATT 交换提议/应答 → 接收方建立 Wi-Fi Direct 组并回传凭据
 *      → 发送方按凭据加入 → TCP 分块传输 → SHA-256 校验。
 * 控制消息（文件数量、总大小、首个文件名、组凭据）只走 BLE；文件数据只走 Wi-Fi Direct/TCP。
 */
@SuppressLint("MissingPermission")
class Transfer(private val ctx: Context) {
    companion object {
        val CTRL: UUID = UUID.fromString("7f1a5d01-6c4e-4b8a-9d3e-f1a5d0c0de01")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        val TEXT: UUID = UUID.fromString("7f1a5d02-6c4e-4b8a-9d3e-f1a5d0c0de01")
        const val MAX_TEXT = 100 * 1024
        const val PORT = 8988
        const val GO_IP = "192.168.49.1" // Wi-Fi Direct 组主固定地址
    }

    val state = MutableStateFlow<UiState>(UiState.Idle)
    val busy get() = state.value.let {
        it is UiState.Waiting || it is UiState.Progress || it is UiState.Incoming ||
            it is UiState.TextIncoming || it is UiState.TextProgress
    }
    /** 文件会话进行中：此时禁止发送/接收文字 */
    val fileLocked get() = busy && mode == "file"

    private val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val p2p = ctx.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
    private val chan = p2p.initialize(ctx, Looper.getMainLooper(), null)
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var server: BluetoothGattServer? = null
    private var ctrl: BluetoothGattCharacteristic? = null
    private var remote: BluetoothDevice? = null
    private var gatt: BluetoothGatt? = null
    private var job: Job? = null
    private var closer: Closeable? = null
    private var cancelled = false
    private var files: List<Item> = emptyList()
    private var offer = ""
    private var mode = ""
    private var peerDev: BluetoothDevice? = null
    private var retries = 0
    private var watchdog: Job? = null
    private var discStarted = false
    private fun discover(g: BluetoothGatt) { if (discStarted) return; discStarted = true; g.discoverServices() }
    private var stageAt = 0L
    private val WIFI_STAGE = "对方已接受，正在建立 Wi-Fi Direct…"
    private val WAIT_STAGE = "等待对方回应…"
    private fun stage(t: String) {
        val s = state.value
        if (s is UiState.Waiting) { state.value = s.copy(stage = t); stageAt = System.currentTimeMillis() }
    }
    private fun connect(dev: BluetoothDevice) {
        peerDev = dev; retries = 0; discStarted = false
        gatt = dev.connectGatt(ctx, false, cliCb, BluetoothDevice.TRANSPORT_LE)
        stageAt = System.currentTimeMillis()
        watchdog?.cancel()
        watchdog = scope.launch {
            while (isActive) {
                delay(1000)
                val w = state.value as? UiState.Waiting ?: break
                // 文件提议在等对方点“接收”给 90 秒；建立 Wi-Fi Direct 给 60 秒；其余（含文字）25 秒
                val limit = when {
                    w.stage == WAIT_STAGE && mode == "file" -> 90_000
                    w.stage == WIFI_STAGE -> 60_000
                    else -> 25_000
                }
                if (System.currentTimeMillis() - stageAt > limit) {
                    fail(IOException("连接超时（卡在：${w.stage}）。请确认对方已打开 FlashDrop 且在前台")); cleanup(); break
                }
            }
        }
    }

    // ---------- 接收方：GATT 服务 ----------
    fun startServer() {
        stopServer()
        val ch = BluetoothGattCharacteristic(CTRL,
            BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_NOTIFY,
            BluetoothGattCharacteristic.PERMISSION_WRITE)
        ch.addDescriptor(BluetoothGattDescriptor(CCCD, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE))
        val svc = BluetoothGattService(Discovery.SERVICE, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        svc.addCharacteristic(ch)
        svc.addCharacteristic(BluetoothGattCharacteristic(TEXT, BluetoothGattCharacteristic.PROPERTY_WRITE, BluetoothGattCharacteristic.PERMISSION_WRITE))
        ctrl = ch
        server = bm.openGattServer(ctx, srvCb)?.also { it.addService(svc) }
    }

    fun stopServer() { runCatching { server?.close() }; server = null }

    private val srvCb = object : BluetoothGattServerCallback() {
        override fun onCharacteristicWriteRequest(d: BluetoothDevice, id: Int, c: BluetoothGattCharacteristic,
                                                  prep: Boolean, resp: Boolean, off: Int, v: ByteArray) {
            if (resp) server?.sendResponse(d, id, BluetoothGatt.GATT_SUCCESS, 0, null)
            if (c.uuid == TEXT) { if (d.address == remote?.address) onTextChunk(v); return }
            val p = String(v).split("|", limit = 4)
            when {
                p[0] == "OFFER" && p.size >= 4 -> {
                    if (busy || state.value !is UiState.Idle) notifyTo(d, "REJECT")
                    else {
                        mode = "file"; remote = d
                        state.value = UiState.Incoming(p[1].toIntOrNull() ?: 0, p[2].toLongOrNull() ?: 0, p[3])
                    }
                }
                p[0] == "TXTOFFER" && p.size >= 2 -> {
                    val n = p[1].toIntOrNull() ?: -1
                    // 文字无需确认，直接接收；正在传输或界面被其他弹窗占用时拒绝，避免覆盖未读内容
                    if (busy || state.value !is UiState.Idle || n !in 1..MAX_TEXT) notifyTo(d, "REJECT")
                    else { remote = d; mode = "text"; rx.reset(); rxExpect = n; acceptText() }
                }
                p[0] == "TXTEND" && p.size >= 2 && d.address == remote?.address -> finishText(p[1])
            }
        }
        override fun onConnectionStateChange(d: BluetoothDevice, st: Int, ns: Int) {
            val s = state.value
            if (ns != BluetoothProfile.STATE_DISCONNECTED || d.address != remote?.address) return
            if (mode == "text" && s is UiState.TextProgress && !s.sending) { rx.reset(); state.value = UiState.Failed("对方已断开连接") }
            else if (s is UiState.Incoming) state.value = UiState.Idle   // 发送方在对方点击前取消了
        }
        override fun onDescriptorWriteRequest(d: BluetoothDevice, id: Int, desc: BluetoothGattDescriptor,
                                              prep: Boolean, resp: Boolean, off: Int, v: ByteArray) {
            if (resp) server?.sendResponse(d, id, BluetoothGatt.GATT_SUCCESS, 0, null)
        }
    }

    private fun notifyPeer(msg: String) = notifyTo(remote, msg)
    private fun notifyTo(d: BluetoothDevice?, msg: String) {
        val c = ctrl ?: return; val dev = d ?: return
        if (Build.VERSION.SDK_INT >= 33) server?.notifyCharacteristicChanged(dev, c, false, msg.toByteArray())
        else { c.value = msg.toByteArray(); server?.notifyCharacteristicChanged(dev, c, false) }
    }

    fun decline() { notifyPeer("REJECT"); state.value = UiState.Idle }

    fun accept() {
        cancelled = false
        state.value = UiState.Progress(false, "", 0, 1, 0.0)
        job = scope.launch {
            try {
                act { p2p.removeGroup(chan, it) }
                if (!act { p2p.createGroup(chan, it) }) throw IOException("无法创建 Wi-Fi Direct 连接，请确认 Wi-Fi 已开启")
                var g: WifiP2pGroup? = null
                for (i in 0 until 10) { g = groupInfo(); if (g != null) break; delay(300) }
                val grp = g ?: throw IOException("读取 Wi-Fi Direct 组信息失败")
                if (grp.passphrase.isNullOrEmpty()) throw IOException("无法获取 Wi-Fi Direct 密码")
                val ss = ServerSocket(PORT).also { closer = it; it.soTimeout = 45_000 }
                notifyPeer("ACCEPT|${grp.networkName}|${grp.passphrase}")
                ss.accept().use { s -> closer = s; receive(s) }
                state.value = UiState.Done(false)
            } catch (e: Exception) { fail(e) } finally { cleanup() }
        }
    }

    private fun receive(s: Socket) {
        val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 65536))
        val n = inp.readInt()
        if (n !in 1..10_000) throw IOException("协议错误")
        val names = ArrayList<String>(); val sizes = ArrayList<Long>()
        repeat(n) { names += inp.readUTF(); sizes += inp.readLong() }
        val total = sizes.sum().coerceAtLeast(1); var done = 0L; val t0 = System.currentTimeMillis(); var last = 0L
        for (i in 0 until n) {
            val md = MessageDigest.getInstance("SHA-256")
            val safe = names[i].replace(Regex("[\\\\/:*?\"<>|]"), "_")
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safe)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/FlashDrop")
            }) ?: throw IOException("无法创建文件")
            ctx.contentResolver.openOutputStream(uri)!!.use { out ->
                val buf = ByteArray(65536); var left = sizes[i]
                while (left > 0) {
                    val r = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (r < 0) throw EOFException("连接中断")
                    out.write(buf, 0, r); md.update(buf, 0, r); left -= r; done += r
                    val now = System.currentTimeMillis()
                    if (now - last > 120) { last = now; progress(false, safe, done, total, t0) }
                }
            }
            val sum = ByteArray(32); inp.readFully(sum)
            if (!MessageDigest.isEqual(sum, md.digest())) {
                ctx.contentResolver.delete(uri, null, null); throw IOException("$safe 校验失败，已删除")
            }
        }
        s.getOutputStream().apply { write(1); flush() }
    }

    // ---------- 文字：只走 BLE ----------
    private val rx = ByteArrayOutputStream()
    private var rxExpect = 0
    private var txBytes = ByteArray(0)
    private var txPos = 0
    private var txStarted = false
    private var mtu = 23

    fun acceptText() {
        state.value = UiState.TextProgress(false, 0, rxExpect)
        notifyPeer("TXTOK")
    }
    private fun onTextChunk(v: ByteArray) {
        if (mode != "text" || state.value !is UiState.TextProgress) return
        rx.write(v)
        if (rx.size() > rxExpect) { state.value = UiState.Failed("文本长度异常"); return }
        state.value = UiState.TextProgress(false, rx.size(), rxExpect)
    }
    private fun finishText(hash: String) {
        if (mode != "text" || state.value !is UiState.TextProgress) return
        val b = rx.toByteArray(); rx.reset()
        if (b.size == rxExpect && hex(b) == hash) {
            notifyPeer("TXTDONE"); state.value = UiState.TextReceived(String(b, Charsets.UTF_8))
        } else { notifyPeer("TXTBAD"); state.value = UiState.Failed("文本校验失败") }
    }
    private fun hex(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    fun sendText(address: String, peerName: String, text: String) {
        val b = text.toByteArray(Charsets.UTF_8)
        if (fileLocked) { state.value = UiState.Failed("文件传输中，暂不可发送文字"); return }
        if (busy) return
        if (b.isEmpty() || b.size > MAX_TEXT) { state.value = UiState.Failed("文本超过 100 KB，请改用文件发送"); return }
        cancelled = false; mode = "text"; txBytes = b; txPos = 0; txStarted = false
        offer = "TXTOFFER|${b.size}"
        state.value = UiState.Waiting(peerName)
        connect(bm.adapter.getRemoteDevice(address))
    }
    private fun nextChunk(g: BluetoothGatt) {
        val svc = g.getService(Discovery.SERVICE) ?: return
        if (txPos >= txBytes.size) {
            val c = svc.getCharacteristic(CTRL)
            c.value = "TXTEND|${hex(txBytes)}".toByteArray(); g.writeCharacteristic(c); return
        }
        val n = minOf(mtu - 3, txBytes.size - txPos)
        val c = svc.getCharacteristic(TEXT)
        c.value = txBytes.copyOfRange(txPos, txPos + n); txPos += n
        state.value = UiState.TextProgress(true, txPos, txBytes.size)
        g.writeCharacteristic(c)
    }

    // ---------- 发送方：GATT 客户端 ----------
    fun send(address: String, peerName: String, items: List<Item>) {
        if (busy || items.isEmpty()) return
        cancelled = false; mode = "file"; files = items
        val first = items.first().name.replace("|", "_").take(60)
        offer = "OFFER|${items.size}|${items.sumOf { it.size }}|$first"
        state.value = UiState.Waiting(peerName)
        connect(bm.adapter.getRemoteDevice(address))
    }

    private val cliCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, ns: Int) {
            if (ns == BluetoothProfile.STATE_CONNECTED) {
                stage("已连接，协商中…")
                if (!g.requestMtu(247)) discover(g) else scope.launch { delay(2000); discover(g) }
            }
            else if (ns == BluetoothProfile.STATE_DISCONNECTED && state.value is UiState.Waiting) {
                val d = peerDev
                if (retries < 2 && d != null) {
                    retries++; discStarted = false; g.close(); stage("重试连接（$retries）…")
                    val cb = this
                    // 关闭后立刻重连在不少机型上会失败，稍等再连
                    scope.launch { delay(500); if (state.value is UiState.Waiting) gatt = d.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE) }
                } else { fail(IOException("蓝牙连接失败（状态码 $st）")); cleanup() }
            }
            else if (ns == BluetoothProfile.STATE_DISCONNECTED && state.value.let { it is UiState.TextProgress && it.sending }) {
                fail(IOException("对方已断开连接")); cleanup()
            }
        }
        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, st: Int) {
            this@Transfer.mtu = if (st == BluetoothGatt.GATT_SUCCESS) mtu else 23
            discover(g)
        }
        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) {
            if (st != BluetoothGatt.GATT_SUCCESS) { fail(IOException("蓝牙写入失败")); cleanup(); return }
            if (c.uuid == TEXT) nextChunk(g)
        }
        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            stage("握手中…")
            val c = g.getService(Discovery.SERVICE)?.getCharacteristic(CTRL)
                ?: run { fail(IOException("对方不是 FlashDrop 或版本不兼容")); cleanup(); return }
            g.setCharacteristicNotification(c, true)
            val d = c.getDescriptor(CCCD)
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(d)
        }
        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, st: Int) {
            if (st != BluetoothGatt.GATT_SUCCESS) { fail(IOException("订阅通知失败（$st）")); cleanup(); return }
            stage(WAIT_STAGE)
            val c = d.characteristic
            c.value = offer.toByteArray()
            g.writeCharacteristic(c)
        }
        // Android 13+ 的新回调默认会转调这个旧回调，只重写这一个即可
        @Deprecated("compat") override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) = reply(g, String(c.value))
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) = reply(g, String(value))
        private fun reply(g: BluetoothGatt, msg: String) {
            val p = msg.split("|")
            when {
                p[0] == "REJECT" -> { fail(IOException("对方已拒绝，或正忙于其他传输")); cleanup() }
                p[0] == "ACCEPT" && p.size >= 3 && job?.isActive != true -> {
                    stage(WIFI_STAGE)
                    job = scope.launch { doSend(p[1], p[2]) }
                }
                p[0] == "TXTOK" -> if (!txStarted) { txStarted = true; nextChunk(g) }
                p[0] == "TXTDONE" -> { state.value = UiState.TextSent; cleanup() }
                p[0] == "TXTBAD" -> { fail(IOException("对方校验失败")); cleanup() }
            }
        }
    }

    private suspend fun doSend(ssid: String, pass: String) {
        try {
            val cfg = WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass).build()
            if (!act { p2p.connect(chan, cfg, it) }) throw IOException("无法加入 Wi-Fi Direct 连接")
            var sock: Socket? = null; val end = System.currentTimeMillis() + 40_000
            while (sock == null && System.currentTimeMillis() < end) {
                val t = Socket()
                try { t.connect(InetSocketAddress(GO_IP, PORT), 2000); sock = t }
                catch (e: IOException) { runCatching { t.close() }; delay(1000) }
            }
            val s = sock ?: throw IOException("连接对方超时")
            s.use {
                closer = it
                val out = DataOutputStream(BufferedOutputStream(it.getOutputStream(), 65536))
                out.writeInt(files.size)
                files.forEach { f -> out.writeUTF(f.name); out.writeLong(f.size) }
                val total = files.sumOf { f -> f.size }.coerceAtLeast(1); var done = 0L; val t0 = System.currentTimeMillis(); var last = 0L
                for (f in files) {
                    val md = MessageDigest.getInstance("SHA-256")
                    ctx.contentResolver.openInputStream(f.uri)!!.use { inp ->
                        val buf = ByteArray(65536); var left = f.size
                        while (left > 0) {
                            val r = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                            if (r < 0) throw EOFException("读取 ${f.name} 失败")
                            out.write(buf, 0, r); md.update(buf, 0, r); left -= r; done += r
                            val now = System.currentTimeMillis()
                            if (now - last > 120) { last = now; progress(true, f.name, done, total, t0) }
                        }
                    }
                    out.write(md.digest())
                }
                out.flush()
                if (it.getInputStream().read() != 1) throw IOException("对方校验失败")
            }
            state.value = UiState.Done(true)
        } catch (e: Exception) { fail(e) } finally { cleanup() }
    }

    // ---------- 公共 ----------
    fun cancel() {
        cancelled = true
        val s = state.value
        if (s is UiState.TextProgress && !s.sending) notifyPeer("REJECT")   // 通知发送方，避免它一直等
        watchdog?.cancel(); job?.cancel(); runCatching { closer?.close() }; cleanup(); state.value = UiState.Idle
    }
    fun reset() { mode = ""; state.value = UiState.Idle }

    private fun progress(sending: Boolean, name: String, done: Long, total: Long, t0: Long) {
        val sec = (System.currentTimeMillis() - t0).coerceAtLeast(1) / 1000.0
        state.value = UiState.Progress(sending, name, done, total, done / sec)
    }
    private fun fail(e: Exception) {
        if (cancelled) return
        state.value = UiState.Failed(when (e) {
            is java.net.SocketTimeoutException -> "等待对方连接超时"
            is CancellationException -> return
            else -> e.message ?: "传输失败"
        })
    }
    private fun cleanup() {
        runCatching { closer?.close() }; closer = null
        runCatching { gatt?.close() }; gatt = null
        runCatching { p2p.removeGroup(chan, null) }
    }
    private suspend fun act(f: (ActionListener) -> Unit): Boolean = suspendCancellableCoroutine { c ->
        f(object : ActionListener {
            override fun onSuccess() { if (c.isActive) c.resumeWith(Result.success(true)) }
            override fun onFailure(r: Int) { if (c.isActive) c.resumeWith(Result.success(false)) }
        })
    }
    private suspend fun groupInfo(): WifiP2pGroup? = suspendCancellableCoroutine { c ->
        p2p.requestGroupInfo(chan) { if (c.isActive) c.resumeWith(Result.success(it)) }
    }
}
