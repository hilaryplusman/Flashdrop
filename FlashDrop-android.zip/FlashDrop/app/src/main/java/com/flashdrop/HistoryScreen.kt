package com.flashdrop

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/** 全局历史只显示最近 10 条；点击名字进入该设备页，查看与它的全部记录。 */
@Composable
fun HistoryScreen(records: List<HistoryItem>, nameOf: (HistoryItem) -> String, onClose: () -> Unit,
                  onOpenDevice: (String) -> Unit, onDelete: (Long) -> Unit, onClear: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var detail by remember { mutableStateOf<HistoryItem?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    val recent = records.take(10)
    Surface(Modifier.fillMaxSize(), color = cs.background) {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClose) { Text("‹ 返回") }
                Spacer(Modifier.weight(1f))
                if (records.isNotEmpty()) TextButton({ confirmClear = true }) { Text("清空", color = cs.error) }
            }
            Text("最近传输", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            Text("只显示最近 10 条，点击名字查看与该设备的全部记录", Modifier.padding(top = 2.dp, bottom = 12.dp),
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            if (recent.isEmpty()) Text("还没有传输记录", Modifier.fillMaxWidth().padding(top = 48.dp),
                textAlign = TextAlign.Center, color = cs.onSurfaceVariant)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(recent, key = { it.id }) { h ->
                    RecordRow(h, nameOf(h), true, { if (h.peerId.isNotEmpty()) onOpenDevice(h.peerId) }) { detail = h }
                }
            }
        }
    }
    detail?.let { h -> RecordDetail(h, nameOf(h), { detail = null }) { onDelete(h.id); detail = null } }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false }, shape = RoundedCornerShape(28.dp),
        title = { Text("清空全部历史？", fontWeight = FontWeight.Bold) },
        text = { Text("只会删除记录，已接收的文件仍保存在 下载/FlashDrop。") },
        confirmButton = { Button({ onClear(); confirmClear = false }, shape = RoundedCornerShape(14.dp)) { Text("清空") } },
        dismissButton = { TextButton({ confirmClear = false }) { Text("取消") } })
}
