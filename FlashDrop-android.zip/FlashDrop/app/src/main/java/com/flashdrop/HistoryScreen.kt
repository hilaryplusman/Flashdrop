package com.flashdrop

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(records: List<HistoryItem>, onClose: () -> Unit, onDelete: (Long) -> Unit, onClear: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var q by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf<HistoryItem?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    val timeFmt = remember { SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()) }
    val shown = records.filter { h ->
        (tab == 0 || (tab == 1 && h.type == "file") || (tab == 2 && h.type == "text")) &&
            (q.isBlank() || h.title.contains(q, true) || (h.text ?: "").contains(q, true) || h.peer.contains(q, true))
    }

    Surface(Modifier.fillMaxSize(), color = cs.background) {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClose) { Text("‹ 返回") }
                Spacer(Modifier.weight(1f))
                if (records.isNotEmpty()) TextButton({ confirmClear = true }) { Text("清空", color = cs.error) }
            }
            Text("传输历史", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(14.dp),
                placeholder = { Text("搜索文件名、文字内容或设备") })
            Spacer(Modifier.height(10.dp))
            Segment(listOf("全部", "文件", "文字"), tab, listOf(true, true, true)) { tab = it }
            Spacer(Modifier.height(10.dp))
            if (shown.isEmpty()) Text(if (records.isEmpty()) "还没有传输记录" else "没有匹配的记录",
                Modifier.fillMaxWidth().padding(top = 48.dp), textAlign = TextAlign.Center, color = cs.onSurfaceVariant)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(shown, key = { it.id }) { h ->
                    Surface(Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).clickable { detail = h },
                        shape = MaterialTheme.shapes.medium, color = cs.surfaceVariant, border = BorderStroke(1.dp, cs.outline)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(40.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
                                Text(if (h.sent) "↑" else "↓", color = cs.onPrimaryContainer, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(h.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                Text("${if (h.type == "file") "文件" else "文字"} · ${if (h.sent) "发送给" else "来自"} ${h.peer} · ${timeFmt.format(Date(h.time))} · ${fmtSize(h.size)}",
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 2)
                            }
                        }
                    }
                }
            }
        }
    }

    detail?.let { h ->
        AlertDialog(
            onDismissRequest = { detail = null }, shape = RoundedCornerShape(28.dp),
            title = { Text(if (h.type == "text") "文字内容" else h.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = {
                if (h.type == "text") SelectionContainer {
                    Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) { Text(h.text ?: h.title) }
                } else Text("${if (h.sent) "发送给" else "来自"} ${h.peer}\n${fmtSize(h.size)} · ${timeFmt.format(Date(h.time))}" +
                    if (!h.sent) "\n保存位置：下载/FlashDrop" else "")
            },
            confirmButton = {
                Button({
                    if (h.type == "text") {
                        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("FlashDrop", h.text ?: h.title))
                        Toast.makeText(ctx, "已复制", Toast.LENGTH_SHORT).show()
                    } else {
                        runCatching {
                            val u = Uri.parse(h.uri)
                            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, ctx.contentResolver.getType(u) ?: "*/*")
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
                        }.onFailure { Toast.makeText(ctx, "无法打开，文件可能已被移动或删除", Toast.LENGTH_LONG).show() }
                    }
                }, shape = RoundedCornerShape(14.dp)) { Text(if (h.type == "text") "一键复制" else "打开") }
            },
            dismissButton = { TextButton({ onDelete(h.id); detail = null }) { Text("删除记录", color = cs.error) } })
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false }, shape = RoundedCornerShape(28.dp),
        title = { Text("清空全部历史？", fontWeight = FontWeight.Bold) },
        text = { Text("只会删除记录，已接收的文件仍保存在 下载/FlashDrop。") },
        confirmButton = { Button({ onClear(); confirmClear = false }, shape = RoundedCornerShape(14.dp)) { Text("清空") } },
        dismissButton = { TextButton({ confirmClear = false }) { Text("取消") } })
}
