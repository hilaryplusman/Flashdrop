package com.flashdrop

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

private fun timeAgo(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when { m < 1 -> "刚刚"; m < 60 -> "$m 分钟前"; m < 1440 -> "${m / 60} 小时前"; else -> "${m / 1440} 天前" }
}

@Composable
fun DeviceRow(name: String, fp: String, avatar: Int, color: Int, sub: String, rssi: Int?, offline: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).clickable(onClick = onClick),
        shape = MaterialTheme.shapes.medium, color = cs.surfaceVariant, border = BorderStroke(1.dp, cs.outline)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(avatar, color, 44.dp, gray = offline)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (offline) cs.onSurfaceVariant.copy(alpha = 0.55f) else cs.onSurface, modifier = Modifier.weight(1f, fill = false))
                    Text("  #$fp", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
                Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            if (rssi != null) Bars(rssi)
        }
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var profile: Profile
    private lateinit var contacts: Contacts
    private lateinit var history: History
    private lateinit var discovery: Discovery
    private lateinit var transfer: Transfer

    private val perms = buildList {
        if (Build.VERSION.SDK_INT >= 31) { add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_ADVERTISE); add(Manifest.permission.BLUETOOTH_CONNECT) }
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES) else add(Manifest.permission.ACCESS_FINE_LOCATION)
    }.toTypedArray()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        enableEdgeToEdge()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        profile = Profile(this); contacts = Contacts(this); history = History(this)
        discovery = Discovery(this, profile, contacts)
        transfer = Transfer(this, history, profile, contacts)
        setContent { FlashTheme { Home() } }
    }

    private fun wifiOn(): Boolean {
        val on = (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager).isWifiEnabled
        if (!on) {
            Toast.makeText(this, "Wi-Fi Direct 需要开启 Wi-Fi，请在面板中打开后重试", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.Panel.ACTION_WIFI))
        }
        return on
    }

    /** 读取文件名和大小；部分文档提供方不返回大小，此时回退到文件描述符长度。 */
    private fun readItems(uris: List<Uri>): List<Item> = uris.mapNotNull { u ->
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (!c.moveToFirst()) return@use null
            val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val si = c.getColumnIndex(OpenableColumns.SIZE)
            val name = if (ni >= 0) c.getString(ni) ?: "file" else "file"
            var size = if (si >= 0 && !c.isNull(si)) c.getLong(si) else -1L
            if (size < 0) size = runCatching { contentResolver.openAssetFileDescriptor(u, "r")?.use { it.length } }.getOrNull() ?: -1L
            if (size < 0) null else Item(u, name, size)
        }
    }

    @Composable
    fun Home() {
        val ctx = LocalContext.current
        val cs = MaterialTheme.colorScheme
        val peers by discovery.peers.collectAsState()
        val adStatus by discovery.status.collectAsState()
        val st by transfer.state.collectAsState()
        val me by profile.data.collectAsState()
        val known by contacts.items.collectAsState()
        val hist by history.items.collectAsState()
        var granted by remember { mutableStateOf(perms.all { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) }
        var btOn by remember { mutableStateOf(discovery.enabled) }
        var chatId by remember { mutableStateOf<String?>(null) }
        var showHistory by remember { mutableStateOf(false) }
        var showProfile by remember { mutableStateOf(false) }
        var target by remember { mutableStateOf<String?>(null) }
        val clip = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val locked = st.let { transfer.fileLocked }
        val busy = st.let { transfer.busy }
        fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
        val ver = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "" }
        val onlineIds = peers.map { it.id }.toSet()
        val offline = known.filter { it.id !in onlineIds }.sortedByDescending { it.lastSeen }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val p = peers.find { it.id == target }
            if (uris.isNotEmpty()) {
                if (p == null) toast("设备已离线")
                else {
                    val list = readItems(uris)
                    if (list.isEmpty()) toast("无法读取所选文件") else transfer.send(p.id, p.addr, contacts.display(p.id, p.name), list)
                }
            }
        }
        val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            granted = r.values.all { it }
            if (!granted) toast("未授权，无法发现附近设备")
        }
        val enableBt = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { btOn = discovery.enabled }

        LaunchedEffect(Unit) { if (!granted) ask.launch(perms) }
        DisposableEffect(Unit) {
            val rc = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { btOn = discovery.enabled } }
            ctx.registerReceiver(rc, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED))
            onDispose { ctx.unregisterReceiver(rc); discovery.stop(); transfer.stopServer() }
        }
        LaunchedEffect(granted, btOn) { if (granted && btOn) transfer.startServer() else transfer.stopServer() }
        // 传输期间暂停扫描和广播（保留设备列表）；名字或头像变化后自动重新广播
        LaunchedEffect(granted, btOn, busy, me) {
            if (!granted || !btOn) discovery.stop() else if (busy) discovery.pause() else discovery.start()
        }

        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clickable { showProfile = true }) { Avatar(me.avatar, me.color, 44.dp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("FlashDrop", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("${me.name} · #${fp(me.id)} · v$ver", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Box(Modifier.clip(RoundedCornerShape(20.dp)).background(cs.surfaceVariant).clickable { showHistory = true }
                    .padding(horizontal = 12.dp, vertical = 6.dp)) { Text("历史", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant) }
            }
            val ok = granted && btOn && adStatus.isEmpty()
            Row(Modifier.padding(vertical = 12.dp).clip(RoundedCornerShape(20.dp)).background(cs.surfaceVariant).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(if (ok) cs.primary else cs.error))
                Spacer(Modifier.width(6.dp))
                Text(when { !granted -> "未授权"; !btOn -> "蓝牙未开启"; adStatus.isNotEmpty() -> adStatus; else -> "可被发现" },
                    style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            }
            if (!granted) Banner("需要“附近的设备”权限才能发现和传输", "授权") { ask.launch(perms) }
            else if (!btOn) Banner("蓝牙未开启，无法发现附近设备", "开启") { enableBt.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }

            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                item { Text("附近设备 · ${peers.size}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold) }
                if (peers.isEmpty()) item {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Radar(110.dp)
                        Text("正在搜索…请让对方也打开 FlashDrop 并开启蓝牙", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
                    }
                }
                items(peers, key = { "on" + it.id }) { p ->
                    DeviceRow(contacts.display(p.id, p.name), fp(p.id), p.avatar, p.color, "点击发送文件或文字", p.rssi, false) { chatId = p.id }
                }
                if (offline.isNotEmpty()) {
                    item { Text("离线设备 · ${offline.size}", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = cs.onSurfaceVariant) }
                    items(offline, key = { "off" + it.id }) { c ->
                        DeviceRow(c.alias.ifBlank { c.name }, fp(c.id), c.avatar, c.color, "上次在线 ${timeAgo(c.lastSeen)} · 点击查看记录", null, true) { chatId = c.id }
                    }
                }
            }
        }

        BackHandler(enabled = chatId != null || showHistory || showProfile) {
            when { chatId != null -> chatId = null; showProfile -> showProfile = false; else -> showHistory = false }
        }
        if (showProfile) ProfileScreen(me, { n, a, c -> profile.save(n, a, c); showProfile = false }) { showProfile = false }
        if (showHistory) HistoryScreen(hist, { h -> contacts.display(h.peerId, h.peer) }, { showHistory = false },
            { id -> chatId = id }, { history.delete(it) }, { history.clear() })
        chatId?.let { id ->
            val c = known.find { it.id == id } ?: Contact(id, "未知设备", 0, 0, "", 0L)
            val online = peers.find { it.id == id }
            DeviceScreen(c, online, hist.filter { it.peerId == id }, st, busy, locked, { chatId = null },
                { text -> if (online == null) toast("设备已离线") else transfer.sendText(id, online.addr, c.alias.ifBlank { c.name }, text) },
                { if (online == null) toast("设备已离线") else if (wifiOn()) { target = id; picker.launch(arrayOf("*/*")) } },
                { alias -> contacts.setAlias(id, alias) }, { history.delete(it) })
        }

        when (val s = st) {
            is UiState.Incoming -> FDialog("收到文件", "接收", { if (wifiOn()) transfer.accept() }, "拒绝", { transfer.decline() }) {
                Text("来自 ${s.from}\n${s.count} 个文件 · ${fmtSize(s.total)}\n${s.first}${if (s.count > 1) " 等" else ""}")
            }
            is UiState.Waiting -> FDialog("正在联系 ${s.peer}", "取消", { transfer.cancel() }) { Text(s.stage) }
            is UiState.Progress -> {
                val left = if (s.speed > 0) ((s.total - s.done) / s.speed).toInt() else 0
                FDialog(if (s.sending) "Sending Files" else "Receiving Files", "Cancel", { transfer.cancel() }) {
                    ProgressBody(s.done.toFloat() / s.total, s.name.ifEmpty { "正在建立连接…" },
                        "${"%.1f".format(s.speed / 1048576)} MB/s · 剩余 $left 秒 · ${fmtSize(s.done)} / ${fmtSize(s.total)}")
                }
            }
            is UiState.Done -> FDialog("Transfer Completed", "Turn Off Wi-Fi", { transfer.reset(); startActivity(Intent(Settings.Panel.ACTION_WIFI)) }, "Keep Wi-Fi On", { transfer.reset() }) {
                Column { CheckBadge(); Spacer(Modifier.height(12.dp)); Text("All files have been successfully transferred. Would you like to turn off Wi-Fi?") }
            }
            is UiState.Failed -> FDialog("传输未完成", "好的", { transfer.reset() }) { Text(s.msg) }
            is UiState.TextIncoming -> FDialog("收到文字", "接收", { transfer.acceptText() }, "拒绝", { transfer.decline() }) { Text("${s.bytes} 字节，仅通过蓝牙传输") }
            is UiState.TextProgress -> FDialog(if (s.sending) "正在发送文字（蓝牙）" else "正在接收文字（蓝牙）", "取消", { transfer.cancel() }) {
                ProgressBody(s.done.toFloat() / s.total.coerceAtLeast(1), "${s.done} / ${s.total} 字节", "蓝牙传输速度较慢，请保持两台手机靠近")
            }
            is UiState.TextReceived -> FDialog("收到文字", "一键复制", {
                clip.setPrimaryClip(ClipData.newPlainText("FlashDrop", s.text)); toast("已复制"); transfer.reset()
            }, "关闭", { transfer.reset() }) {
                Column {
                    if (s.from.isNotEmpty()) Text("来自 ${s.from}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    SelectionContainer { Column(Modifier.heightIn(max = 280.dp).verticalScroll(rememberScrollState())) { Text(s.text) } }
                }
            }
            UiState.TextSent -> FDialog("文字已发送", "好的", { transfer.reset() }) {
                Column { CheckBadge(); Spacer(Modifier.height(12.dp)); Text("对方已收到并校验通过") }
            }
            UiState.Idle -> {}
        }
    }
}
