package com.flashdrop

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ───────────── 可复用组件 ─────────────

@Composable
fun Radar(size: Dp) {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "p")
    val c = MaterialTheme.colorScheme.primary
    Canvas(Modifier.size(size)) {
        val r = this.size.minDimension / 2
        for (i in 0..2) {
            val q = (p + i / 3f) % 1f
            drawCircle(c.copy(alpha = (1f - q) * 0.35f), radius = r * (0.35f + 0.65f * q), style = Stroke(2.dp.toPx()))
        }
        drawCircle(c, radius = r * 0.32f)
        val s = r * 0.32f; val m = center
        val bolt = Path().apply {
            moveTo(m.x - s * 0.30f, m.y - s * 0.55f); lineTo(m.x + s * 0.60f, m.y)
            lineTo(m.x - s * 0.30f, m.y + s * 0.55f); close()
        }
        drawPath(bolt, Color.White)
    }
}

@Composable
fun Bars(rssi: Int) {
    val lvl = when { rssi > -60 -> 4; rssi > -70 -> 3; rssi > -82 -> 2; else -> 1 }
    val on = MaterialTheme.colorScheme.primary; val off = MaterialTheme.colorScheme.outline
    Canvas(Modifier.size(22.dp, 16.dp)) {
        val bw = size.width / 4f * 0.7f
        for (i in 0..3) {
            val h = size.height * (i + 1) / 4f
            drawRoundRect(if (i < lvl) on else off, Offset(i * size.width / 4f, size.height - h), Size(bw, h), CornerRadius(2.dp.toPx()))
        }
    }
}

@Composable
fun PeerCard(p: Peer, textMode: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).clickable(enabled = enabled, onClick = onClick),
        shape = MaterialTheme.shapes.medium, color = cs.surfaceVariant, border = BorderStroke(1.dp, cs.outline)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
                Text(p.name.take(1).uppercase(), fontWeight = FontWeight.Bold, color = cs.onPrimaryContainer)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (textMode) "点击发送文字" else "点击选择文件", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            if (textMode) Box(Modifier.clip(RoundedCornerShape(12.dp)).background(cs.primary).padding(horizontal = 14.dp, vertical = 8.dp)) {
                Text("发送", color = cs.onPrimary, fontWeight = FontWeight.SemiBold)
            } else Bars(p.rssi)
        }
    }
}

@Composable
fun Segment(labels: List<String>, selected: Int, enabled: List<Boolean>, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.outline.copy(alpha = 0.35f)).padding(4.dp)) {
        labels.forEachIndexed { i, l ->
            val sel = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                    .background(if (sel) cs.primary else Color.Transparent)
                    .clickable(enabled = enabled[i]) { onSelect(i) }.padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) { Text(l, fontWeight = FontWeight.SemiBold, color = if (sel) cs.onPrimary else cs.onSurface.copy(alpha = if (enabled[i]) 1f else 0.4f)) }
        }
    }
}

@Composable
fun Banner(msg: String, action: String, onAction: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(Modifier.fillMaxWidth().padding(bottom = 10.dp), shape = MaterialTheme.shapes.medium, color = cs.errorContainer) {
        Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(msg, Modifier.weight(1f), color = cs.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
            TextButton(onAction) { Text(action, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun FDialog(title: String, confirm: String, onConfirm: () -> Unit, dismiss: String? = null,
            onDismiss: () -> Unit = {}, body: @Composable () -> Unit) {
    AlertDialog(
        onDismissRequest = {}, shape = RoundedCornerShape(28.dp),
        title = { Text(title, fontWeight = FontWeight.Bold) }, text = body,
        confirmButton = { Button(onConfirm, shape = RoundedCornerShape(14.dp)) { Text(confirm) } },
        dismissButton = dismiss?.let { d -> @Composable { TextButton(onDismiss) { Text(d) } } })
}

@Composable
fun ProgressBody(frac: Float, line1: String, line2: String) {
    val cs = MaterialTheme.colorScheme
    val f = frac.coerceIn(0f, 1f)
    Column {
        Text("${(f * 100).toInt()}%", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = cs.primary)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator({ f }, Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)), trackColor = cs.outline)
        Spacer(Modifier.height(12.dp))
        Text(line1, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(line2, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
    }
}

@Composable
fun CheckBadge() {
    Box(Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
        Text("✓", color = MaterialTheme.colorScheme.onPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    }
}

private fun fmt(b: Long) = when {
    b >= 1L shl 30 -> "%.2f GB".format(b / 1073741824.0)
    b >= 1L shl 20 -> "%.1f MB".format(b / 1048576.0)
    else -> "%.0f KB".format(b / 1024.0)
}

// ───────────── Activity ─────────────

class MainActivity : ComponentActivity() {
    private lateinit var discovery: Discovery
    private lateinit var transfer: Transfer
    private lateinit var history: History

    private val perms = buildList {
        if (Build.VERSION.SDK_INT >= 31) { add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_ADVERTISE); add(Manifest.permission.BLUETOOTH_CONNECT) }
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES) else add(Manifest.permission.ACCESS_FINE_LOCATION)
    }.toTypedArray()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        enableEdgeToEdge()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        discovery = Discovery(this); history = History(this); transfer = Transfer(this, history)
        setContent { FlashTheme { Home() } }
    }

    private fun wifiOn(): Boolean {
        val on = (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager).isWifiEnabled
        if (!on) {
            Toast.makeText(this, "Wi-Fi Direct 需要开启 Wi-Fi，请在面板中打开后重试", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.Panel.ACTION_WIFI))
        }
        return on
    }

    /** 读取文件名和大小；部分文档提供方不返回大小，此时回退到文件描述符长度。 */
    private fun readItems(uris: List<Uri>): List<Item> = uris.mapNotNull { u ->
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (!c.moveToFirst()) return@use null
            val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val si = c.getColumnIndex(OpenableColumns.SIZE)
            val name = if (ni >= 0) c.getString(ni) ?: "file" else "file"
            var size = if (si >= 0 && !c.isNull(si)) c.getLong(si) else -1L
            if (size < 0) size = runCatching { contentResolver.openAssetFileDescriptor(u, "r")?.use { it.length } }.getOrNull() ?: -1L
            if (size < 0) null else Item(u, name, size)
        }
    }

    @Composable
    fun Home() {
        val ctx = LocalContext.current
        val cs = MaterialTheme.colorScheme
        val peers by discovery.peers.collectAsState()
        val adStatus by discovery.status.collectAsState()
        val st by transfer.state.collectAsState()
        var granted by remember { mutableStateOf(perms.all { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) }
        var btOn by remember { mutableStateOf(discovery.enabled) }
        var textMode by remember { mutableStateOf(false) }
        var text by remember { mutableStateOf("") }
        var target by remember { mutableStateOf<Peer?>(null) }
        var showHistory by remember { mutableStateOf(false) }
        val hist by history.items.collectAsState()
        val clip = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val locked = st.let { transfer.fileLocked }
        val busy = st.let { transfer.busy }
        fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
        val ver = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "" }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val p = target
            if (p != null && uris.isNotEmpty()) {
                val list = readItems(uris)
                if (list.isEmpty()) toast("无法读取所选文件") else transfer.send(p.id, p.name, list)
            }
        }
        val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            granted = r.values.all { it }
            if (!granted) toast("未授权，无法发现附近设备")
        }
        val enableBt = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { btOn = discovery.enabled }

        LaunchedEffect(Unit) { if (!granted) ask.launch(perms) }
        DisposableEffect(Unit) {
            val rc = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { btOn = discovery.enabled } }
            ctx.registerReceiver(rc, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED))
            onDispose { ctx.unregisterReceiver(rc); discovery.stop(); transfer.stopServer() }
        }
        LaunchedEffect(granted, btOn) { if (granted && btOn) transfer.startServer() else transfer.stopServer() }
        // 传输期间暂停扫描和广播：高占空比的扫描会挤占射频，导致蓝牙传输卡住
        LaunchedEffect(granted, btOn, busy) { if (granted && btOn && !busy) discovery.start() else discovery.stop() }
        LaunchedEffect(st) { if (st is UiState.TextSent) text = "" }
        LaunchedEffect(locked) { if (locked) textMode = false }

        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(horizontal = 20.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("FlashDrop", Modifier.weight(1f), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                Box(Modifier.clip(RoundedCornerShape(20.dp)).background(cs.surfaceVariant).clickable { showHistory = true }
                    .padding(horizontal = 12.dp, vertical = 6.dp)) { Text("历史 ${hist.size}", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant) }
                Spacer(Modifier.width(8.dp))
                val ok = granted && btOn && adStatus.isEmpty()
                Row(Modifier.clip(RoundedCornerShape(20.dp)).background(cs.surfaceVariant).padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(if (ok) cs.primary else cs.error))
                    Spacer(Modifier.width(6.dp))
                    Text(when { !granted -> "未授权"; !btOn -> "蓝牙未开启"; adStatus.isNotEmpty() -> adStatus; else -> "可被发现" },
                        style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                }
            }
            Text("快速、简单、离线的手机间传输 · v$ver", Modifier.padding(top = 2.dp, bottom = 16.dp), color = cs.onSurfaceVariant)

            Segment(listOf("发送文件", "发送文本"), if (textMode) 1 else 0, listOf(true, !locked)) { textMode = it == 1 }
            Spacer(Modifier.height(12.dp))

            if (!granted) Banner("需要“附近的设备”权限才能发现和传输", "授权") { ask.launch(perms) }
            else if (!btOn) Banner("蓝牙未开启，无法发现附近设备", "开启") { enableBt.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }

            if (locked) Text("文件传输中，暂不可发送文字", color = cs.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 8.dp))
            if (textMode && !locked) {
                Surface(Modifier.fillMaxWidth().padding(bottom = 12.dp), shape = MaterialTheme.shapes.medium, color = cs.surfaceVariant, border = BorderStroke(1.dp, cs.outline)) {
                    Column(Modifier.padding(14.dp)) {
                        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), minLines = 3, maxLines = 5,
                            shape = RoundedCornerShape(14.dp), placeholder = { Text("输入要发送的文字，仅通过蓝牙传输") })
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton({
                                val t = clip.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString()
                                if (!t.isNullOrEmpty()) text = t else toast("剪贴板为空")
                            }) { Text("粘贴剪贴板") }
                            Spacer(Modifier.weight(1f))
                            val kb = text.toByteArray().size / 1024.0
                            Text("%.1f / 100 KB".format(kb), style = MaterialTheme.typography.labelMedium, color = if (kb > 100) cs.error else cs.onSurfaceVariant)
                        }
                    }
                }
            }

            Box(Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = Alignment.Center) { Radar(if (peers.isEmpty() && !textMode) 170.dp else 84.dp) }
            Text(if (peers.isEmpty()) "正在搜索附近的设备…" else "附近设备 · ${peers.size}",
                Modifier.fillMaxWidth().padding(vertical = 8.dp), style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold, textAlign = if (peers.isEmpty()) TextAlign.Center else TextAlign.Start)
            if (peers.isEmpty()) Text("请让对方也打开 FlashDrop 并开启蓝牙", Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)

            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(peers, key = { it.id }) { p ->
                    PeerCard(p, textMode, !busy) {
                        if (textMode) { if (text.isNotBlank()) transfer.sendText(p.id, p.name, text) else toast("请先输入文字") }
                        else if (wifiOn()) { target = p; picker.launch(arrayOf("*/*")) }
                    }
                }
            }
        }

        BackHandler(enabled = showHistory) { showHistory = false }
        if (showHistory) HistoryScreen(hist, { showHistory = false }, { history.delete(it) }, { history.clear() })

        when (val s = st) {
            is UiState.Incoming -> FDialog("收到文件", "接收", { if (wifiOn()) transfer.accept() }, "拒绝", { transfer.decline() }) {
                Text("${s.count} 个文件 · ${fmt(s.total)}\n${s.first}${if (s.count > 1) " 等" else ""}")
            }
            is UiState.Waiting -> FDialog("正在联系 ${s.peer}", "取消", { transfer.cancel() }) { Text(s.stage) }
            is UiState.Progress -> {
                val left = if (s.speed > 0) ((s.total - s.done) / s.speed).toInt() else 0
                FDialog(if (s.sending) "Sending Files" else "Receiving Files", "Cancel", { transfer.cancel() }) {
                    ProgressBody(s.done.toFloat() / s.total, s.name.ifEmpty { "正在建立连接…" },
                        "${"%.1f".format(s.speed / 1048576)} MB/s · 剩余 $left 秒 · ${fmt(s.done)} / ${fmt(s.total)}")
                }
            }
            is UiState.Done -> FDialog("Transfer Completed", "Turn Off Wi-Fi", { transfer.reset(); startActivity(Intent(Settings.Panel.ACTION_WIFI)) }, "Keep Wi-Fi On", { transfer.reset() }) {
                Column { CheckBadge(); Spacer(Modifier.height(12.dp)); Text("All files have been successfully transferred. Would you like to turn off Wi-Fi?") }
            }
            is UiState.Failed -> FDialog("传输未完成", "好的", { transfer.reset() }) { Text(s.msg) }
            is UiState.TextIncoming -> FDialog("收到文字", "接收", { transfer.acceptText() }, "拒绝", { transfer.decline() }) { Text("${s.bytes} 字节，仅通过蓝牙传输") }
            is UiState.TextProgress -> FDialog(if (s.sending) "正在发送文字（蓝牙）" else "正在接收文字（蓝牙）", "取消", { transfer.cancel() }) {
                ProgressBody(s.done.toFloat() / s.total.coerceAtLeast(1), "${s.done} / ${s.total} 字节", "蓝牙传输速度较慢，请保持两台手机靠近")
            }
            is UiState.TextReceived -> FDialog("收到文字", "一键复制", {
                clip.setPrimaryClip(ClipData.newPlainText("FlashDrop", s.text)); toast("已复制"); transfer.reset()
            }, "关闭", { transfer.reset() }) {
                SelectionContainer { Column(Modifier.heightIn(max = 280.dp).verticalScroll(rememberScrollState())) { Text(s.text) } }
            }
            UiState.TextSent -> FDialog("文字已发送", "好的", { transfer.reset() }) {
                Column { CheckBadge(); Spacer(Modifier.height(12.dp)); Text("对方已收到并校验通过") }
            }
            UiState.Idle -> {}
        }
    }
}
