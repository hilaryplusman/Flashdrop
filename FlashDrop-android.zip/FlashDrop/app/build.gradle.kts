plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.flashdrop"
    compileSdk = 34
    defaultConfig { applicationId = "com.flashdrop"; minSdk = 29; targetSdk = 34; versionCode = 4; versionName = "0.4-test" }
    // 固定调试签名：每次编译签名一致，后续版本可以直接覆盖安装
    signingConfigs.getByName("debug") {
        storeFile = file("debug.keystore"); storePassword = "android"
        keyAlias = "androiddebugkey"; keyPassword = "android"
    }
    buildFeatures { compose = true }
    kotlinOptions { jvmTarget = "17" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
}
