# 本应用代码很小，整体保留，避免压缩时误删蓝牙回调等被系统调用的代码
-keep class com.flashdrop.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-dontwarn org.jetbrains.annotations.**
